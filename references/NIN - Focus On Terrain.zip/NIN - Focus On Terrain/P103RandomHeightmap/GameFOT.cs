/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the GameFOT class.
    /// </summary>
    public class GameFOT : Microsoft.Xna.Framework.Game
    {
        /// <summary>
        /// GameFOT class instance.
        /// </summary>
        static GameFOT _instance;

        /// <summary>
        /// Graphics device manager.
        /// </summary>
        GraphicsDeviceManager _graphicsManager;

        /// <summary>
        /// Input manager.
        /// </summary>
        InputManager _inputManager;

        /// <summary>
        /// Content manager.
        /// </summary>
        ContentManager _contentManager;

        /// <summary>
        /// Window aspect ratio.
        /// </summary>
        float _aspectRatio;

        /// <summary>
        /// Fly camera.
        /// </summary>
        FlyCamera _flyCamera;

        /// <summary>
        /// Terrain.
        /// </summary>
        Terrain _terrain;

        /// <summary>
        /// Return the instance of GameFOT.
        /// </summary>
        public static GameFOT Instance
        {
            get
            {
                return _instance;
            }
        }

        /// <summary>
        /// Graphics device.
        /// </summary>
        public GraphicsDevice GraphicsDevice
        {
            get
            {
                return _graphicsManager.GraphicsDevice;
            }
        }

        /// <summary>
        /// Aspect ratio.
        /// </summary>
        public float AspectRatio
        {
            get
            {
                return _aspectRatio;
            }
        }

        /// <summary>
        /// Content manager.
        /// </summary>
        public ContentManager ContentManager
        {
            get
            {
                return _contentManager;
            }
        }

        /// <summary>
        /// Input manager.
        /// </summary>
        public InputManager InputManager
        {
            get
            {
                return _inputManager;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public GameFOT()
        {
            _instance = this;

            this.Window.Title = "XNA - Focus on terrain - 103 Random heightmap :. http://nerdy-inverse.com";

            _graphicsManager = new GraphicsDeviceManager(this);

            _graphicsManager.PreferredDepthStencilFormat = DepthFormat.Depth24Stencil8;

            _contentManager = new ContentManager(Services);

            _inputManager = new InputManager();

            _flyCamera = new FlyCamera();

            _flyCamera.Position = new Vector3(0.0f, 6.0f, 0.0f);
            _flyCamera.Rotation = new Vector3(0.5f, 0.0f, 0.0f);

            _terrain = new Terrain(32, 32, 0.0f, 3.0f);
        }

        /// <summary>
        /// Load the graphics content.
        /// </summary>
        /// <param name="loadAllContent"></param>
        protected override void LoadGraphicsContent(bool loadAllContent)
        {
            _aspectRatio = _graphicsManager.GraphicsDevice.Viewport.Width / (float)_graphicsManager.GraphicsDevice.Viewport.Height;

            if (loadAllContent)
            {
                _terrain.LoadGraphicsContent();
            }
        }

        /// <summary>
        /// Unload the graphics content.
        /// </summary>
        /// <param name="unloadAllContent"></param>
        protected override void UnloadGraphicsContent(bool unloadAllContent)
        {
            if (unloadAllContent)
            {
                _contentManager.Unload();
            }
        }

        /// <summary>
        /// Update the game.
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Update(GameTime gameTime)
        {
            _inputManager.Update();

            if (_inputManager.CurrentGamePadState.Buttons.Back == ButtonState.Pressed ||
                _inputManager.CurrentKeyboardState.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }

            if ((_inputManager.CurrentGamePadState.Buttons.A == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.A == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.Space) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.Space)))
            {
                _terrain.IsWireframe = !_terrain.IsWireframe;
            }

            if ((_inputManager.CurrentGamePadState.Buttons.B == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.B == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.Enter) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.Enter)))
            {
                _terrain.GenerateRandomTerrain(32, 32, 0.0f, 3.0f);
            }

            _flyCamera.Update(gameTime);

            base.Update(gameTime);
        }

        /// <summary>
        /// Draw the game.
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Draw(GameTime gameTime)
        {
            _graphicsManager.GraphicsDevice.Clear(Color.CornflowerBlue);

            _terrain.Draw(gameTime, _flyCamera.View, _flyCamera.Projection);

            base.Draw(gameTime);
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/
