/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the GameFOT class.
    /// </summary>
    public class GameFOT : Microsoft.Xna.Framework.Game
    {
        /// <summary>
        /// GameFOT class instance.
        /// </summary>
        static GameFOT _instance;

        /// <summary>
        /// Graphics device manager.
        /// </summary>
        GraphicsDeviceManager _graphicsManager;

        /// <summary>
        /// Input manager.
        /// </summary>
        InputManager _inputManager;

        /// <summary>
        /// Content manager.
        /// </summary>
        ContentManager _contentManager;

        /// <summary>
        /// Window aspect ratio.
        /// </summary>
        float _aspectRatio;

        /// <summary>
        /// Fly camera.
        /// </summary>
        FlyCamera _flyCamera;

        /// <summary>
        /// Terrain.
        /// </summary>
        Terrain _terrain;

        /// <summary>
        /// Heightmap.
        /// </summary>
        Heightmap _heightmap;

        /// <summary>
        /// Current heightmap index.
        /// </summary>
        int _heightmapIndex;

        /// <summary>
        /// Current heightmap type.
        /// </summary>
        String _heightmapType;

        /// <summary>
        /// Is it the first run ?
        /// </summary>
        bool _isFirstRun;

        /// <summary>
        /// Sprite batch.
        /// </summary>
        SpriteBatch _spriteBatch;

        /// <summary>
        /// Sprite font.
        /// </summary>
        SpriteFont _spriteFont;

        /// <summary>
        /// Return the instance of GameFOT.
        /// </summary>
        public static GameFOT Instance
        {
            get
            {
                return _instance;
            }
        }

        /// <summary>
        /// Graphics device.
        /// </summary>
        public GraphicsDevice GraphicsDevice
        {
            get
            {
                return _graphicsManager.GraphicsDevice;
            }
        }

        /// <summary>
        /// Aspect ratio.
        /// </summary>
        public float AspectRatio
        {
            get
            {
                return _aspectRatio;
            }
        }

        /// <summary>
        /// Content manager.
        /// </summary>
        public ContentManager ContentManager
        {
            get
            {
                return _contentManager;
            }
        }

        /// <summary>
        /// Input manager.
        /// </summary>
        public InputManager InputManager
        {
            get
            {
                return _inputManager;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public GameFOT()
        {
            _instance = this;

            this.Window.Title = "XNA - Focus on terrain - 303 Particle deposition :. http://nerdy-inverse.com";

            _graphicsManager = new GraphicsDeviceManager(this);

            _graphicsManager.PreferredDepthStencilFormat = DepthFormat.Depth24Stencil8;

            _contentManager = new ContentManager(Services);

            _inputManager = new InputManager();

            _isFirstRun = true;
        }

        /// <summary>
        /// Initialize scene.
        /// </summary>
        public void InitializeScene()
        {
            // Create the fly camera.
            _flyCamera = new FlyCamera();

            // We set the camera above the terrain.
            _flyCamera.Position = new Vector3(40.0f, 50.0f, 50.0f);
            _flyCamera.Rotation = new Vector3(0.5f, 0.0f, 0.0f);

            // Load the heightmap data in a color array..
            Texture2D heightmapTexture = _contentManager.Load<Texture2D>("Content/Heightmaps/TerrainHeightmap");

            Color[] textureData = new Color[heightmapTexture.Width * heightmapTexture.Height];

            heightmapTexture.GetData<Color>(textureData);

            // Convert the data into a float array.
            int width = heightmapTexture.Width;
            int depth = heightmapTexture.Height;

            float minimumHeight = 0.0f;
            float maximumHeight = 30.0f;

            float scale = 50.0f;

            float[] data = new float[width * depth];

            // When using a greyscale, Texture2D.GetData<>() will set the same value for all R, G and B components
            // with an alpha component set to 255. The scale variable 
            for (int x = 0; x < width; ++x)
            {
                for (int z = 0; z < depth; ++z)
                {
                    data[x + width * z] = (float)textureData[x + width * z].R / 255.0f * scale;
                }
            }

            // Create the heightmap.
            _heightmap = new Heightmap(width, depth, minimumHeight, maximumHeight, data);

            // Set the heightmap index.
            _heightmapIndex = 0;

            // Set the heightmap type.
            _heightmapType = "TerrainHeightmap.bmp";

            // Create the terrain.
            _terrain = new Terrain(_heightmap);
        }

        /// <summary>
        /// Load the graphics content.
        /// </summary>
        /// <param name="loadAllContent"></param>
        protected override void LoadGraphicsContent(bool loadAllContent)
        {
            _aspectRatio = _graphicsManager.GraphicsDevice.Viewport.Width / (float)_graphicsManager.GraphicsDevice.Viewport.Height;

            if (loadAllContent)
            {
                if (_isFirstRun)
                {
                    InitializeScene();

                    _isFirstRun = false;
                }

                _terrain.LoadGraphicsContent();

                _spriteBatch = new SpriteBatch(_graphicsManager.GraphicsDevice);

                _spriteFont = _contentManager.Load<SpriteFont>("Content/Fonts/DefaultFont");
            }
        }

        /// <summary>
        /// Unload the graphics content.
        /// </summary>
        /// <param name="unloadAllContent"></param>
        protected override void UnloadGraphicsContent(bool unloadAllContent)
        {
            if (unloadAllContent)
            {
                _contentManager.Unload();
            }
        }

        /// <summary>
        /// Update the game.
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Update(GameTime gameTime)
        {
            _inputManager.Update();

            if (_inputManager.CurrentGamePadState.Buttons.Back == ButtonState.Pressed ||
                _inputManager.CurrentKeyboardState.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }

            if ((_inputManager.CurrentGamePadState.Buttons.A == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.A == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.Space) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.Space)))
            {
                _terrain.IsWireframe = !_terrain.IsWireframe;
            }

            if ((_inputManager.CurrentGamePadState.Buttons.B == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.B == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.Enter) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.Enter)))
            {
                ++_heightmapIndex;

                switch (_heightmapIndex)
                {
                    case 1:
                        {
                            // Generate a random heightmap.
                            _terrain.Heightmap.GenerateRandomHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Random heightmap";
                        }
                        break;

                    case 2:
                        {
                            // Generate a random heightmap using fault formation.
                            HeightmapFaultSettings settings = new HeightmapFaultSettings(4, 256, 4, 4, 0.3f);

                            _terrain.Heightmap.FaultSettings = settings;
                            _terrain.Heightmap.GenerateFaultHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Fault formation: minD " + settings.MinimumDelta.ToString();
                            _heightmapType += " maxD " + settings.MaximumDelta.ToString();
                            _heightmapType += " i " + settings.Iterations.ToString();
                            _heightmapType += " iPF " + settings.IterationsPerFilter.ToString();
                            _heightmapType += " filter " + settings.FilterValue.ToString();
                        }
                        break;

                    case 3:
                        {
                            // Generate a random heightmap using fault formation.
                            HeightmapFaultSettings settings = new HeightmapFaultSettings(8, 256, 128, 16, 0.7f);

                            _terrain.Heightmap.FaultSettings = settings;
                            _terrain.Heightmap.GenerateFaultHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Fault formation: minD " + settings.MinimumDelta.ToString();
                            _heightmapType += " maxD " + settings.MaximumDelta.ToString();
                            _heightmapType += " i " + settings.Iterations.ToString();
                            _heightmapType += " iPF " + settings.IterationsPerFilter.ToString();
                            _heightmapType += " filter " + settings.FilterValue.ToString();
                        }
                        break;

                    case 4:
                        {
                            // Generate a random heightmap using fault formation.
                            HeightmapFaultSettings settings = new HeightmapFaultSettings(16, 256, 1024, 128, 0.5f);

                            _terrain.Heightmap.FaultSettings = settings;
                            _terrain.Heightmap.GenerateFaultHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Fault formation: minD " + settings.MinimumDelta.ToString();
                            _heightmapType += " maxD " + settings.MaximumDelta.ToString();
                            _heightmapType += " i " + settings.Iterations.ToString();
                            _heightmapType += " iPF " + settings.IterationsPerFilter.ToString();
                            _heightmapType += " filter " + settings.FilterValue.ToString();
                        }
                        break;

                    case 5:
                        {
                            // Generate a random heightmap using mid point displacement.
                            HeightmapMidPointSettings settings = new HeightmapMidPointSettings(1.0f);

                            _terrain.Heightmap.MidPointSettings = settings;
                            _terrain.Heightmap.GenerateMidPointHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Mid point displacement: rough " + settings.Rough.ToString();
                        }
                        break;

                    case 6:
                        {
                            // Generate a random heightmap using mid point displacement.
                            HeightmapMidPointSettings settings = new HeightmapMidPointSettings(0.25f);

                            _terrain.Heightmap.MidPointSettings = settings;
                            _terrain.Heightmap.GenerateMidPointHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Mid point displacement: rough " + settings.Rough.ToString();
                        }
                        break;

                    case 7:
                        {
                            // Generate a random heightmap using mid point displacement.
                            HeightmapMidPointSettings settings = new HeightmapMidPointSettings(4.0f);

                            _terrain.Heightmap.MidPointSettings = settings;
                            _terrain.Heightmap.GenerateMidPointHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Mid point displacement: rough " + settings.Rough.ToString();
                        }
                        break;

                    case 8:
                        {
                            // Generate a random heightmap using particle deposition.
                            HeightmapParticleDepositionSettings settings = new HeightmapParticleDepositionSettings(0.7f, 1024, 4, 128, 1024);

                            _terrain.Heightmap.ParticleDepositionSettings = settings;
                            _terrain.Heightmap.GenerateParticleDepositionHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Particle deposition: c " + settings.Caldera.ToString();
                            _heightmapType += " j " + settings.Jumps.ToString();
                            _heightmapType += " pw " + settings.PeakWalk.ToString();
                            _heightmapType += " min " + settings.MinParticlesPerJump.ToString();
                            _heightmapType += " max " + settings.MaxParticlesPerJump.ToString();
                        }
                        break;

                    case 9:
                        {
                            // Generate a random heightmap using particle deposition.
                            HeightmapParticleDepositionSettings settings = new HeightmapParticleDepositionSettings(0.5f, 1024, 2, 128, 1024);

                            _terrain.Heightmap.ParticleDepositionSettings = settings;
                            _terrain.Heightmap.GenerateParticleDepositionHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Particle deposition: c " + settings.Caldera.ToString();
                            _heightmapType += " j " + settings.Jumps.ToString();
                            _heightmapType += " pw " + settings.PeakWalk.ToString();
                            _heightmapType += " min " + settings.MinParticlesPerJump.ToString();
                            _heightmapType += " max " + settings.MaxParticlesPerJump.ToString();
                        }
                        break;

                    case 10:
                        {
                            // Generate a random heightmap using particle deposition.
                            HeightmapParticleDepositionSettings settings = new HeightmapParticleDepositionSettings(0.3f, 1024, 8, 128, 1024);

                            _terrain.Heightmap.ParticleDepositionSettings = settings;
                            _terrain.Heightmap.GenerateParticleDepositionHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Particle deposition: c " + settings.Caldera.ToString();
                            _heightmapType += " j " + settings.Jumps.ToString();
                            _heightmapType += " pw " + settings.PeakWalk.ToString();
                            _heightmapType += " min " + settings.MinParticlesPerJump.ToString();
                            _heightmapType += " max " + settings.MaxParticlesPerJump.ToString();
                        }
                        break;

                    case 11:
                        {
                            // Generate a random heightmap using particle deposition.
                            HeightmapParticleDepositionSettings settings = new HeightmapParticleDepositionSettings(0.5f, 128, 2, 128, 1024);

                            _terrain.Heightmap.ParticleDepositionSettings = settings;
                            _terrain.Heightmap.GenerateParticleDepositionHeightmap();
                            _terrain.BuildTerrain();

                            _heightmapType = "Particle deposition: c " + settings.Caldera.ToString();
                            _heightmapType += " j " + settings.Jumps.ToString();
                            _heightmapType += " pw " + settings.PeakWalk.ToString();
                            _heightmapType += " min " + settings.MinParticlesPerJump.ToString();
                            _heightmapType += " max " + settings.MaxParticlesPerJump.ToString();
                        }
                        break;

                    default:
                        {
                            // Load the default heightmap.
                            _heightmapIndex = 0;

                            _terrain.Heightmap = (Heightmap)_heightmap.Clone();
                            _terrain.BuildTerrain();

                            _heightmapType = "TerrainHeightmap.bmp";
                        }
                        break;
                }
            }

            _flyCamera.Update(gameTime);

            base.Update(gameTime);
        }

        /// <summary>
        /// Draw the game.
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Draw(GameTime gameTime)
        {
            _graphicsManager.GraphicsDevice.Clear(Color.CornflowerBlue);

            _terrain.Draw(gameTime, _flyCamera.View, _flyCamera.Projection, _flyCamera.Frustum);

            _spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Immediate, SaveStateMode.SaveState);

            _spriteBatch.DrawString(_spriteFont, "Patch count: " + _terrain.PatchCount, new Vector2(10, 10), Color.Yellow);
            _spriteBatch.DrawString(_spriteFont, "Drawn patch count: " + _terrain.DrawnPatchCount, new Vector2(10, 30), Color.Yellow);
            _spriteBatch.DrawString(_spriteFont, "Heightmap type: " + _heightmapType, new Vector2(10, 50), Color.Yellow);

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/
