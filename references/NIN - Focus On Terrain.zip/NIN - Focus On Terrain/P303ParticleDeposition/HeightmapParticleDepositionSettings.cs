/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// Heightmap particle deposition settings.
    /// </summary>
    public class HeightmapParticleDepositionSettings
    {
        /// <summary>
        /// Caldera height.
        /// </summary>
        float _caldera;

        /// <summary>
        /// Number of jumps.
        /// </summary>
        int _jumps;

        /// <summary>
        /// Peak walk value.
        /// </summary>
        int _peakWalk;

        /// <summary>
        /// Minimum particles per jump.
        /// </summary>
        int _minParticlesPerJump;

        /// <summary>
        /// Maximum particles per jump.
        /// </summary>
        int _maxParticlesPerJump;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public HeightmapParticleDepositionSettings()
        {
            _caldera = 0.0f;

            _jumps = 0;
            _peakWalk = 0;

            _minParticlesPerJump = 0;
            _maxParticlesPerJump = 0;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="caldera"></param>
        /// <param name="jumps"></param>
        /// <param name="peakWalk"></param>
        /// <param name="minParticlesPerJump"></param>
        /// <param name="maxParticlesPerJump"></param>
        public HeightmapParticleDepositionSettings(float caldera, int jumps, int peakWalk, int minParticlesPerJump, int maxParticlesPerJump)
        {
            _caldera = caldera;

            _jumps = jumps;
            _peakWalk = peakWalk;

            _minParticlesPerJump = minParticlesPerJump;
            _maxParticlesPerJump = maxParticlesPerJump;
        }

        /// <summary>
        /// Get or set the caldera height.
        /// </summary>
        public float Caldera
        {
            get
            {
                return _caldera;
            }
            set
            {
                 _caldera = value;
            }
        }

        /// <summary>
        /// Get or set the number of jumps.
        /// </summary>
        public int Jumps
        {
            get
            {
                return _jumps;
            }
            set
            {
                 _jumps = value;
            }
        }

        /// <summary>
        /// Get or set the peak walk value.
        /// </summary>
        public int PeakWalk
        {
            get
            {
                return _peakWalk;
            }
            set
            {
                 _peakWalk = value;
            }
        }

        /// <summary>
        /// Get or set the minimum particles per jump count.
        /// </summary>
        public int MinParticlesPerJump
        {
            get
            {
                return _minParticlesPerJump;
            }
            set
            {
                 _maxParticlesPerJump = value;
            }
        }

        /// <summary>
        /// Get or set the maximum particles per jump count.
        /// </summary>
        public int MaxParticlesPerJump
        {
            get
            {
                return _maxParticlesPerJump;
            }
            set
            {
                _maxParticlesPerJump = value;
            }
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/