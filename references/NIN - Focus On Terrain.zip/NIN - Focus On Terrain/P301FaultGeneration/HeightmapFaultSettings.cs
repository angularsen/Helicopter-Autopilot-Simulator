/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// Heightmap fault settings.
    /// </summary>
    public class HeightmapFaultSettings
    {
        /// <summary>
        /// Minimum delta value.
        /// </summary>
        int _minimumDelta;

        /// <summary>
        /// Maximum delta value.
        /// </summary>
        int _maximumDelta;

        /// <summary>
        /// Iterations value.
        /// </summary>
        int _iterations;

        /// <summary>
        /// Iterations per filter value.
        /// </summary>
        int _iterationsPerFilter;

        /// <summary>
        /// Filter value.
        /// </summary>
        float _filterValue;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public HeightmapFaultSettings()
        {
            _minimumDelta = 0;
            _maximumDelta = 0;

            _iterations = 0;
            _iterationsPerFilter = 0;

            _filterValue = 0.0f;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="minDelta"></param>
        /// <param name="maxDelta"></param>
        /// <param name="iterations"></param>
        /// <param name="iterationsPerFilter"></param>
        /// <param name="filterValue"></param>
        public HeightmapFaultSettings(int minDelta, int maxDelta, int iterations, int iterationsPerFilter, float filterValue)
        {
            _minimumDelta = minDelta;
            _maximumDelta = maxDelta;

            _iterations = iterations;
            _iterationsPerFilter = iterationsPerFilter;

            _filterValue = filterValue;
        }

        /// <summary>
        /// Get or set the minimum delta value.
        /// </summary>
        public int MinimumDelta
        {
            get
            {
                return _minimumDelta;
            }
            set
            {
                _minimumDelta = value;
            }
        }

        /// <summary>
        /// Get or set the maximum delta value.
        /// </summary>
        public int MaximumDelta
        {
            get
            {
                return _maximumDelta;
            }
            set
            {
                _maximumDelta = value;
            }
        }

        /// <summary>
        /// Get or set the iterations count.
        /// </summary>
        public int Iterations
        {
            get
            {
                return _iterations;
            }
            set
            {
                _iterations = value;
            }
        }

        /// <summary>
        /// Get or set the iterations count per filter value.
        /// </summary>
        public int IterationsPerFilter
        {
            get
            {
                return _iterationsPerFilter;
            }
            set
            {
                _iterationsPerFilter = value;
            }
        }

        /// <summary>
        /// Get or set the filter value.
        /// </summary>
        public float FilterValue
        {
            get
            {
                return _filterValue;
            }
            set
            {
                _filterValue = value;
            }
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/