/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the terrain class.
    /// </summary>
    public class Terrain
    {
        /// <summary>
        /// Heightmap used to generate the terrain mesh.
        /// </summary>
        Heightmap _heightmap;

        /// <summary>
        /// Texture used to represent the lowest heights of the terrain.
        /// </summary>
        Texture2D _groundTexture;

        /// <summary>
        /// Texture used to represent the heights above the ground.
        /// </summary>
        Texture2D _mudTexture;

        /// <summary>
        /// Texture used to represent the heights above the mud.
        /// </summary>
        Texture2D _rockTexture;

        /// <summary>
        /// Texture used to represent the highest heights of the terrain.
        /// </summary>
        Texture2D _snowTexture;

        /// <summary>
        /// Vertex declaration of the terrain mesh.
        /// </summary>
        VertexDeclaration _vertexDeclaration;

        /// <summary>
        /// Terrain effect shader.
        /// </summary>
        Effect _effect;

        /// <summary>
        /// World matrix.
        /// </summary>
        Matrix _worldMatrix;

        /// <summary>
        /// Wireframe fill mode flag.
        /// </summary>
        bool _isWireframe;

        /// <summary>
        /// List of the terrain patches.
        /// </summary>
        List<TerrainPatch> _patches;

        /// <summary>
        /// Patch count.
        /// </summary>
        int _patchCount;

        /// <summary>
        /// Drawn patch count.
        /// </summary>
        int _drawnPatchCount;

        /// <summary>
        /// Get or set the wireframe fill mode.
        /// </summary>
        public bool IsWireframe
        {
            get
            {
                return _isWireframe;
            }
            set
            {
                _isWireframe = value;
            }
        }

        /// <summary>
        /// The heightmap used by the terrain.
        /// </summary>
        public Heightmap Heightmap
        {
            get
            {
                return _heightmap;
            }
            set
            {
                _heightmap = value;
            }
        }

        /// <summary>
        /// Patch count.
        /// </summary>
        public int PatchCount
        {
            get
            {
                return _patchCount;
            }
        }

        /// <summary>
        /// Drawn patch count.
        /// </summary>
        public int DrawnPatchCount
        {
            get
            {
                return _drawnPatchCount;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="heightmap"></param>
        public Terrain(Heightmap heightmap)
        {
            _patches = new List<TerrainPatch>();

            _heightmap = (Heightmap)heightmap.Clone();
        }

        /// <summary>
        /// Load the graphics content and also build the mesh.
        /// </summary>
        public void LoadGraphicsContent()
        {
            _effect = GameFOT.Instance.ContentManager.Load<Effect>("Content/Effects/TerrainEffect");

            _effect.CurrentTechnique = _effect.Techniques["DefaultTechnique"];

            _groundTexture = GameFOT.Instance.ContentManager.Load<Texture2D>("Content/Textures/TerrainGround");
            _mudTexture = GameFOT.Instance.ContentManager.Load<Texture2D>("Content/Textures/TerrainMud");
            _rockTexture = GameFOT.Instance.ContentManager.Load<Texture2D>("Content/Textures/TerrainRock");
            _snowTexture = GameFOT.Instance.ContentManager.Load<Texture2D>("Content/Textures/TerrainSnow");

            BuildTerrain();
        }

        /// <summary>
        /// Draw the terrain.
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="viewMatrix"></param>
        /// <param name="projectionMatrix"></param>
        /// <param name="frustum"></param>
        public void Draw(GameTime gameTime, Matrix viewMatrix, Matrix projectionMatrix, BoundingFrustum frustum)
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            _patchCount = _patches.Count;
            _drawnPatchCount = 0;

            if (_isWireframe)
            {
                GameFOT.Instance.GraphicsDevice.RenderState.FillMode = FillMode.WireFrame;
            }
            else
            {
                GameFOT.Instance.GraphicsDevice.RenderState.FillMode = FillMode.Solid;
            }

            GameFOT.Instance.GraphicsDevice.RenderState.DepthBufferEnable = true;
            GameFOT.Instance.GraphicsDevice.RenderState.DepthBufferWriteEnable = true;

            Matrix worldViewProjection = _worldMatrix * viewMatrix * projectionMatrix;

            Vector3 lightDirection = new Vector3(-20.0f * (float)Math.Sin(gameTime.TotalRealTime.TotalMilliseconds * 0.0001f), 0.0f, -20.0f * (float)Math.Cos(gameTime.TotalRealTime.TotalMilliseconds * 0.0001f));

            GameFOT.Instance.GraphicsDevice.VertexDeclaration = _vertexDeclaration;

            _effect.Parameters["g_matWorldViewProjection"].SetValue(worldViewProjection);

            _effect.Parameters["g_vecLightDirection"].SetValue(lightDirection);

            _effect.Parameters["g_vecHeights"].SetValue(new Vector3(7.5f, 15.0f, 22.5f));

            _effect.Parameters["g_texGround"].SetValue(_groundTexture);
            _effect.Parameters["g_texMud"].SetValue(_mudTexture);
            _effect.Parameters["g_texRock"].SetValue(_rockTexture);
            _effect.Parameters["g_texSnow"].SetValue(_snowTexture);

            _effect.Begin();
            
            foreach (EffectPass pass in _effect.CurrentTechnique.Passes)
            {
                pass.Begin();

                for (int i = 0; i < _patches.Count; ++i)
                {
                    // Test the patch against frustum.
                    if (frustum.Contains(_patches[i].BoundingBox) != ContainmentType.Disjoint)
                    {
                        _patches[i].Draw();

                        ++_drawnPatchCount;
                    }
                }

                pass.End();
            }
            
            _effect.End();

            if (_isWireframe)
            {
                GameFOT.Instance.GraphicsDevice.RenderState.FillMode = FillMode.Solid;
            }
        }

        /// <summary>
        /// Build the terrain.
        /// </summary>
        public void BuildTerrain()
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            // Clear the terrain patches.
            _patches.Clear();

            // Compute the world matrix to place the terrain in the middle of the scene.
            _worldMatrix = Matrix.CreateTranslation((float)width * -0.5f, 0.0f, (float)depth * -0.5f);

            // Create the terrain patches.
            int patchWidth = 16;
            int patchDepth = 16;
            int patchCountX = width / patchWidth;
            int patchCountZ = depth / patchDepth;
            int patchCount = patchCountX * patchCountZ;

            for (int x = 0; x < patchCountX; ++x)
            {
                for (int z = 0; z < patchCountZ; ++z)
                {
                    TerrainPatch patch = new TerrainPatch();

                    patch.BuildPatch(_heightmap, _worldMatrix, patchWidth, patchDepth, x * (patchWidth - 1), z * (patchDepth - 1));

                    _patches.Add(patch);
                }
            }

            _vertexDeclaration = new VertexDeclaration(GameFOT.Instance.GraphicsDevice, VertexPositionNormalTexture.VertexElements);
        }

        /// <summary>
        /// Save the terrain to a file.
        /// </summary>
        /// <param name="filename"></param>
        public void SaveToFile(String filename)
        {
            _heightmap.SaveToFile(filename);
        }

        /// <summary>
        /// Load the terrain from a file and build the terrain.
        /// </summary>
        /// <param name="filename"></param>
        public void LoadFromFile(String filename)
        {
            _heightmap.LoadFromFile(filename);

            BuildTerrain();
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/