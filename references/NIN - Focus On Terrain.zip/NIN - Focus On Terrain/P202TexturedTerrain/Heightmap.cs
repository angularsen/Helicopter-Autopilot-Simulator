/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the heightmap class.
    /// </summary>
    public class Heightmap
    {
        /// <summary>
        /// Width of the heightmap.
        /// </summary>
        int _width;

        /// <summary>
        /// Depth of the heightmap.
        /// </summary>
        int _depth;

        /// <summary>
        /// Minimum height of the heightmap.
        /// </summary>
        float _minimumHeight;

        /// <summary>
        /// Maximum height of the heightmap.
        /// </summary>
        float _maximumHeight;

        /// <summary>
        /// Height values of the heightmap.
        /// </summary>
        float[] _heightValues;

        /// <summary>
        /// Get the width of the heightmap.
        /// </summary>
        public int Width
        {
            get
            {
                return _width;
            }
        }

        /// <summary>
        /// Get the depth of the heightmap.
        /// </summary>
        public int Depth
        {
            get
            {
                return _depth;
            }
        }

        /// <summary>
        /// Minimum height of the heightmap.
        /// </summary>
        public float MinimumHeight
        {
            get
            {
                return _minimumHeight;
            }
        }

        /// <summary>
        /// Maximum height of the heightmap.
        /// </summary>
        public float MaximumHeight
        {
            get
            {
                return _maximumHeight;
            }
        }

        /// <summary>
        /// Height values of the heightmap.
        /// </summary>
        public float[] HeightValues
        {
            get
            {
                return _heightValues;
            }
        }

        /// <summary>
        /// Default constructor for a flat heightmap.
        /// </summary>
        public Heightmap()
        {
            _width = 0;
            _depth = 0;

            _minimumHeight = 0.0f;
            _maximumHeight = 0.0f;

            _heightValues = null;
        }

        /// <summary>
        /// Default constructor for a prebuilt heightmap.
        /// </summary>
        /// <param name="width"></param>
        /// <param name="depth"></param>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <param name="data"></param>
        public Heightmap(int width, int depth, float min, float max, float[] data)
        {
            _width = width;
            _depth = depth;

            _minimumHeight = min;
            _maximumHeight = max;

            _heightValues = (float[])data.Clone();
        }

        /// <summary>
        /// Return the height at the given x,z coordinate.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <returns></returns>
        public float GetHeightValue(int x, int z)
        {
            return _heightValues[x + z * _width];
        }

        /// <summary>
        /// Set the height value at the given x,z coordinate.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <param name="value"></param>
        public void SetHeightValue(int x, int z, float value)
        {
            if (value > _maximumHeight)
            {
                value = _maximumHeight;
            }

            if (value < _minimumHeight)
            {
                value = _minimumHeight;
            }

            _heightValues[x + z * _width] = value;
        }

        /// <summary>
        /// Return the percentage of the height based on the minimum and maximum values at the given x,z coordinate.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <returns></returns>
        public float GetHeightPercentage(int x, int z)
        {
            return (_heightValues[x + z * _width] / _maximumHeight);
        }

        /// <summary>
        /// Generate a random heightmap.
        /// </summary>
        public void GenerateRandomHeightmap()
        {
            Random random = new Random();

            for (int x = 0; x < _width; ++x)
            {
                for (int z = 0; z < _depth; ++z)
                {
                    _heightValues[x + z * _width] = (float)random.NextDouble() * (_maximumHeight - _minimumHeight) + _minimumHeight;
                }
            }
        }

        /// <summary>
        /// Generate a random heightmap.
        /// </summary>
        /// <param name="width"></param>
        /// <param name="depth"></param>
        /// <param name="min"></param>
        /// <param name="max"></param>
        public void GenerateRandomHeightmap(int width, int depth, float min, float max)
        {
            _width = width;
            _depth = depth;

            _minimumHeight = min;
            _maximumHeight = max;

            _heightValues = new float[_width * _depth];

            GenerateRandomHeightmap();
        }

        /// <summary>
        /// Save a heightmap to a file.
        /// </summary>
        /// <param name="filename"></param>
        public void SaveToFile(String filename)
        {
            try
            {
                FileStream stream = File.Open(filename, FileMode.OpenOrCreate);

                if (stream != null)
                {
                    BinaryWriter writer = new BinaryWriter(stream);

                    writer.Write(_width);
                    writer.Write(_depth);

                    writer.Write(_minimumHeight);
                    writer.Write(_maximumHeight);

                    for (int i = 0; i < _heightValues.Length; ++i)
                    {
                        writer.Write(_heightValues[i]);
                    }

                    writer.Flush();

                    stream.Close();
                }
            }
            catch (Exception)
            {

            }
        }

        /// <summary>
        /// Load a heightmap from a file.
        /// </summary>
        /// <param name="filename"></param>
        public void LoadFromFile(String filename)
        {
            try
            {
                FileStream stream = File.Open(filename, FileMode.Open);

                BinaryReader reader = new BinaryReader(stream);

                _width = reader.ReadInt32();
                _depth = reader.ReadInt32();

                _minimumHeight = reader.ReadSingle();
                _maximumHeight = reader.ReadSingle();

                _heightValues = new float[_width * _depth];

                for (int i = 0; i < _heightValues.Length; ++i)
                {
                    _heightValues[i] = reader.ReadSingle();
                }

                reader.Close();

                stream.Close();
            }
            catch (Exception)
            {

            }
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/
