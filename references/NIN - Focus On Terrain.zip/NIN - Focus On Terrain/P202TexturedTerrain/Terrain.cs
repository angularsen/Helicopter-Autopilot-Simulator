/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the terrain class.
    /// </summary>
    public class Terrain
    {
        /// <summary>
        /// Heightmap used to generate the terrain mesh.
        /// </summary>
        Heightmap _heightmap;

        /// <summary>
        /// Texture used to represent the lowest heights of the terrain.
        /// </summary>
        Texture2D _groundTexture;

        /// <summary>
        /// Texture used to represent the heights above the ground.
        /// </summary>
        Texture2D _mudTexture;

        /// <summary>
        /// Texture used to represent the heights above the mud.
        /// </summary>
        Texture2D _rockTexture;

        /// <summary>
        /// Texture used to represent the highest heights of the terrain.
        /// </summary>
        Texture2D _snowTexture;

        /// <summary>
        /// Terrain mesh geometry.
        /// </summary>
        VertexPositionNormalTexture[] _geometry;

        /// <summary>
        /// Terrain mesh indices.
        /// </summary>
        short[] _indices;

        /// <summary>
        /// Vertex buffer of the terrain mesh.
        /// </summary>
        VertexBuffer _vertexBuffer;

        /// <summary>
        /// Index buffer of the terrain mesh.
        /// </summary>
        IndexBuffer _indexBuffer;

        /// <summary>
        /// Vertex declaration of the terrain mesh.
        /// </summary>
        VertexDeclaration _vertexDeclaration;

        /// <summary>
        /// Primitive type used by the terrain mesh.
        /// </summary>
        PrimitiveType _primitiveType;

        /// <summary>
        /// Terrain effect shader.
        /// </summary>
        Effect _effect;

        /// <summary>
        /// World matrix.
        /// </summary>
        Matrix _worldMatrix;

        /// <summary>
        /// Wireframe fill mode flag.
        /// </summary>
        bool _isWireframe;

        /// <summary>
        /// Get or set the wireframe fill mode.
        /// </summary>
        public bool IsWireframe
        {
            get
            {
                return _isWireframe;
            }
            set
            {
                _isWireframe = value;
            }
        }

        /// <summary>
        /// The heightmap used by the terrain.
        /// </summary>
        public Heightmap Heightmap
        {
            get
            {
                return _heightmap;
            }
            set
            {
                _heightmap = value;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="heightmap"></param>
        public Terrain(Heightmap heightmap)
        {
            _heightmap = heightmap;
        }

        /// <summary>
        /// Load the graphics content and also build the mesh.
        /// </summary>
        public void LoadGraphicsContent()
        {
            _effect = GameFOT.Instance.ContentManager.Load<Effect>("Content/Effects/TerrainEffect");

            _effect.CurrentTechnique = _effect.Techniques["DefaultTechnique"];

            _groundTexture = GameFOT.Instance.ContentManager.Load<Texture2D>("Content/Textures/TerrainGround");
            _mudTexture = GameFOT.Instance.ContentManager.Load<Texture2D>("Content/Textures/TerrainMud");
            _rockTexture = GameFOT.Instance.ContentManager.Load<Texture2D>("Content/Textures/TerrainRock");
            _snowTexture = GameFOT.Instance.ContentManager.Load<Texture2D>("Content/Textures/TerrainSnow");

            BuildTerrainMesh();
        }

        /// <summary>
        /// Draw the terrain.
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="viewMatrix"></param>
        /// <param name="projectionMatrix"></param>
        public void Draw(GameTime gameTime, Matrix viewMatrix, Matrix projectionMatrix)
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            int primitivePerStrip = (depth - 1) * 2;
            int stripCount = width - 1;
            int vertexPerStrip = depth * 2;

            if (_isWireframe)
            {
                GameFOT.Instance.GraphicsDevice.RenderState.FillMode = FillMode.WireFrame;
            }
            else
            {
                GameFOT.Instance.GraphicsDevice.RenderState.FillMode = FillMode.Solid;
            }

            GameFOT.Instance.GraphicsDevice.RenderState.DepthBufferEnable = true;
            GameFOT.Instance.GraphicsDevice.RenderState.DepthBufferWriteEnable = true;

            Matrix worldViewProjection = _worldMatrix * viewMatrix * projectionMatrix;

            Vector3 lightDirection = new Vector3(-20.0f * (float)Math.Sin(gameTime.TotalRealTime.TotalMilliseconds * 0.0001f), 0.0f, -20.0f * (float)Math.Cos(gameTime.TotalRealTime.TotalMilliseconds * 0.0001f));

            GameFOT.Instance.GraphicsDevice.VertexDeclaration = _vertexDeclaration;

            _effect.Parameters["g_matWorldViewProjection"].SetValue(worldViewProjection);

            _effect.Parameters["g_vecLightDirection"].SetValue(lightDirection);

            _effect.Parameters["g_vecHeights"].SetValue(new Vector3(14.0f, 21.0f, 28.0f));

            _effect.Parameters["g_texGround"].SetValue(_groundTexture);
            _effect.Parameters["g_texMud"].SetValue(_mudTexture);
            _effect.Parameters["g_texRock"].SetValue(_rockTexture);
            _effect.Parameters["g_texSnow"].SetValue(_snowTexture);

            _effect.Begin();

            for (int s = 0; s < stripCount; ++s)
            {
                foreach (EffectPass pass in _effect.CurrentTechnique.Passes)
                {
                    pass.Begin();

                    GameFOT.Instance.GraphicsDevice.Vertices[0].SetSource(_vertexBuffer, 0, VertexPositionNormalTexture.SizeInBytes);

                    GameFOT.Instance.GraphicsDevice.Indices = _indexBuffer;

                    GameFOT.Instance.GraphicsDevice.DrawIndexedPrimitives(_primitiveType, 0, 0, _geometry.Length, vertexPerStrip * s, primitivePerStrip);

                    pass.End();
                }
            }
            
            _effect.End();
        }

        /// <summary>
        /// Build the vertex buffer of the terrain mesh.
        /// </summary>
        private void BuildVertexBuffer()
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            _worldMatrix = Matrix.CreateTranslation((float)width * -0.5f, 0.0f, (float)depth * -0.5f);

            int index = 0;

            Vector3 position;
            Vector3 normal;

            _geometry = new VertexPositionNormalTexture[width * depth];

            for (int z = 0; z < depth; ++z)
            {
                for (int x = 0; x < width; ++x)
                {
                    position = new Vector3((float)x, _heightmap.GetHeightValue(x, z), (float)z);

                    ComputeVertexNormal(x, z, out normal);

                    _geometry[index] = new VertexPositionNormalTexture(position, normal, new Vector2(x, z));

                    ++index;
                }
            }
        }

        /// <summary>
        /// Compute normal for the given x,z coordinate.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <param name="normal"></param>
        private void ComputeVertexNormal(int x, int z, out Vector3 normal)
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            Vector3 center;
            Vector3 p1;
            Vector3 p2;
            Vector3 avgNormal = Vector3.Zero;

            int avgCount = 0;

            bool spaceAbove = false;
            bool spaceBelow = false;
            bool spaceLeft = false;
            bool spaceRight = false;

            Vector3 tmpNormal;
            Vector3 v1;
            Vector3 v2;

            center = new Vector3((float)x, _heightmap.GetHeightValue(x, z), (float)z);

            if (x > 0)
            {
                spaceLeft = true;
            }

            if (x < width - 1)
            {
                spaceRight = true;
            }

            if (z > 0)
            {
                spaceAbove = true;
            }

            if (z < depth - 1)
            {
                spaceBelow = true;
            }

            if (spaceAbove && spaceLeft)
            {
                p1 = new Vector3(x - 1, _heightmap.GetHeightValue(x - 1, z), z);
                p2 = new Vector3(x - 1, _heightmap.GetHeightValue(x - 1, z - 1), z - 1);

                v1 = p1 - center;
                v2 = p2 - p1;

                tmpNormal = Vector3.Cross(v1, v2);
                avgNormal += tmpNormal;

                ++avgCount;
            }

            if (spaceAbove && spaceRight)
            {
                p1 = new Vector3(x, _heightmap.GetHeightValue(x, z - 1), z - 1);
                p2 = new Vector3(x + 1, _heightmap.GetHeightValue(x + 1, z - 1), z - 1);

                v1 = p1 - center;
                v2 = p2 - p1;

                tmpNormal = Vector3.Cross(v1, v2);
                avgNormal += tmpNormal;

                ++avgCount;
            }

            if (spaceBelow && spaceRight)
            {
                p1 = new Vector3(x + 1, _heightmap.GetHeightValue(x + 1, z), z);
                p2 = new Vector3(x + 1, _heightmap.GetHeightValue(x + 1, z + 1), z + 1);

                v1 = p1 - center;
                v2 = p2 - p1;

                tmpNormal = Vector3.Cross(v1, v2);
                avgNormal += tmpNormal;

                ++avgCount;
            }

            if (spaceBelow && spaceLeft)
            {
                p1 = new Vector3(x, _heightmap.GetHeightValue(x, z + 1), z + 1);
                p2 = new Vector3(x - 1, _heightmap.GetHeightValue(x - 1, z + 1), z + 1);

                v1 = p1 - center;
                v2 = p2 - p1;

                tmpNormal = Vector3.Cross(v1, v2);
                avgNormal += tmpNormal;

                ++avgCount;
            }

            normal = avgNormal / avgCount;
        }

        /// <summary>
        /// Build the index buffer of the terrain mesh.
        /// </summary>
        private void BuildIndexBuffer()
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            int stripLength = 4 + (depth - 2) * 2;
            int stripCount = width - 1;

            _indices = new short[stripLength * stripCount];

            int index = 0;

            for (int s = 0; s < stripCount; ++s)
            {
                for (int z = 0; z < depth; ++z)
                {
                    _indices[index] = (short)(s + depth * z);

                    ++index;

                    _indices[index] = (short)(s + depth * z + 1);

                    ++index;
                }
            }
        }

        /// <summary>
        /// Build the terrain mesh.
        /// </summary>
        public void BuildTerrainMesh()
        {
            BuildVertexBuffer();

            _primitiveType = PrimitiveType.TriangleStrip;

            _vertexDeclaration = new VertexDeclaration(GameFOT.Instance.GraphicsDevice, VertexPositionNormalTexture.VertexElements);

            _vertexBuffer = new VertexBuffer(GameFOT.Instance.GraphicsDevice, VertexPositionNormalTexture.SizeInBytes * _geometry.Length, ResourceUsage.WriteOnly, ResourceManagementMode.Automatic);

            _vertexBuffer.SetData<VertexPositionNormalTexture>(_geometry);

            BuildIndexBuffer();

            _indexBuffer = new IndexBuffer(GameFOT.Instance.GraphicsDevice, sizeof(short) * _indices.Length, ResourceUsage.WriteOnly, IndexElementSize.SixteenBits);

            _indexBuffer.SetData<short>(_indices);
        }

        /// <summary>
        /// Save the terrain to a file.
        /// </summary>
        /// <param name="filename"></param>
        public void SaveToFile(String filename)
        {
            _heightmap.SaveToFile(filename);
        }

        /// <summary>
        /// Load the terrain from a file and rebuild the terrain mesh.
        /// </summary>
        /// <param name="filename"></param>
        public void LoadFromFile(String filename)
        {
            _heightmap.LoadFromFile(filename);

            BuildTerrainMesh();
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/