/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// Heightmap perlin noise settings.
    /// </summary>
    public class HeightmapPerlinNoiseSettings
    {
        /// <summary>
        /// Seed value.
        /// </summary>
        int _seed;

        /// <summary>
        /// Persistence value.
        /// </summary>
        float _persistence;

        /// <summary>
        /// Octaves count.
        /// </summary>
        int _octaves;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public HeightmapPerlinNoiseSettings()
        {
            _seed = 0;
            _persistence = 0.0f;
            _octaves = 0;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="seed"></param>
        /// <param name="persistence"></param>
        /// <param name="octaves"></param>
        public HeightmapPerlinNoiseSettings(int seed, float persistence, int octaves)
        {
            _seed = seed;
            _persistence = persistence;
            _octaves = octaves;
        }

        /// <summary>
        /// Get or set the seed value.
        /// </summary>
        public int Seed
        {
            get
            {
                return _seed;
            }
            set
            {
                 _seed = value;
            }
        }

        /// <summary>
        /// Get or set the persistence value.
        /// </summary>
        public float Persistence
        {
            get
            {
                return _persistence;
            }
            set
            {
                _persistence = value;
            }
        }

        /// <summary>
        /// Get or set the octaves count.
        /// </summary>
        public int Octaves
        {
            get
            {
                return _octaves;
            }
            set
            {
                 _octaves = value;
            }
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/
