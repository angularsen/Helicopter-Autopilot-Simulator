/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the fly camera class.
    /// </summary>
    public class FlyCamera
    {
        /// <summary>
        /// Position of the camera.
        /// </summary>
        Vector3 _position;

        /// <summary>
        /// Rotation of the camera.
        /// </summary>
        Vector3 _rotation;

        /// <summary>
        /// Move speed modifier for the camera.
        /// </summary>
        const float _moveSpeedModifier = 2.0f;

        /// <summary>
        /// Turn speed modifier for the camera.
        /// </summary>
        const float _turnSpeedModifier = 1.0f;

        /// <summary>
        /// View matrix.
        /// </summary>
        Matrix _view;

        /// <summary>
        /// Projection matrix.
        /// </summary>
        Matrix _projection;

        /// <summary>
        /// Get or set the position of the camera.
        /// </summary>
        public Vector3 Position
        {
            get
            {
                return _position;
            }
            set
            {
                _position = value;
            }
        }

        /// <summary>
        /// Get or set the rotation of the camera.
        /// </summary>
        public Vector3 Rotation
        {
            get
            {
                return _rotation;
            }
            set
            {
                _rotation = value;
            }
        }

        /// <summary>
        /// Get the view matrix.
        /// </summary>
        public Matrix View
        {
            get
            {
                return _view;
            }
        }

        /// <summary>
        /// Get the projection matrix.
        /// </summary>
        public Matrix Projection
        {
            get
            {
                return _projection;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public FlyCamera()
        {
            _position = Vector3.Zero;
            _rotation = Vector3.Zero;
        }

        /// <summary>
        /// Update the camera.
        /// </summary>
        /// <param name="gameTime"></param>
        public void Update(GameTime gameTime)
        {
            // Get the elapsed seconds since the last game time.
            float elapsedTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // Get the rotation angle from the right thumbstick.
            _rotation.X += MathHelper.ToRadians(-GameFOT.Instance.InputManager.CurrentGamePadState.ThumbSticks.Right.Y * _turnSpeedModifier);
            _rotation.Y += MathHelper.ToRadians(GameFOT.Instance.InputManager.CurrentGamePadState.ThumbSticks.Right.X * _turnSpeedModifier);

            // Get the rotation angle from the keyboard.
            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.Left))
            {
                _rotation.Y += MathHelper.ToRadians(-1.0f * _turnSpeedModifier);
            }

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.Right))
            {
                _rotation.Y += MathHelper.ToRadians(1.0f * _turnSpeedModifier);
            }

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.Down))
            {
                _rotation.X += MathHelper.ToRadians(1.0f * _turnSpeedModifier);
            }

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.Up))
            {
                _rotation.X += MathHelper.ToRadians(-1.0f * _turnSpeedModifier);
            }

            // Compute the forward and left vector from the rotation angle.
            Vector3 forward = Vector3.Normalize(new Vector3((float)Math.Sin(-_rotation.Y), (float)Math.Sin(_rotation.X), (float)Math.Cos(-_rotation.Y)));
            Vector3 left = Vector3.Normalize(new Vector3((float)Math.Cos(_rotation.Y), 0.0f, (float)Math.Sin(_rotation.Y)));

            // Move the camera to the left or right relative to the camera left vector.
            _position += left * GameFOT.Instance.InputManager.CurrentGamePadState.ThumbSticks.Left.X * _moveSpeedModifier * elapsedTime;

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.A))
            {
                _position += left * -1.0f * _moveSpeedModifier * elapsedTime;
            }

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.D))
            {
                _position += left * 1.0f * _moveSpeedModifier * elapsedTime;
            }

            // Move the camera up or down relative to the unit up vector.
            _position += Vector3.Up * (-GameFOT.Instance.InputManager.CurrentGamePadState.Triggers.Left +
                         GameFOT.Instance.InputManager.CurrentGamePadState.Triggers.Right) * _moveSpeedModifier * elapsedTime;

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.Q))
            {
                _position += Vector3.Up * 1.0f * _moveSpeedModifier * elapsedTime;
            }

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.E))
            {
                _position += Vector3.Up * -1.0f * _moveSpeedModifier * elapsedTime;
            }

            // Move the camera forward or backward relative to the camera forward vector.
            _position -= forward * GameFOT.Instance.InputManager.CurrentGamePadState.ThumbSticks.Left.Y * _moveSpeedModifier * elapsedTime;

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.S))
            {
                _position -= forward * -1.0f * _moveSpeedModifier * elapsedTime;
            }

            if (GameFOT.Instance.InputManager.CurrentKeyboardState.IsKeyDown(Keys.W))
            {
                _position -= forward * 1.0f * _moveSpeedModifier * elapsedTime;
            }

            // Compute the view and projection matrix.
            _view = Matrix.CreateTranslation(-_position) * Matrix.CreateRotationZ(_rotation.Z) * Matrix.CreateRotationY(_rotation.Y) * Matrix.CreateRotationX(_rotation.X);
            _projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, GameFOT.Instance.AspectRatio, 0.1f, 1000.0f);
        }
    }
}

/*======================================================================================================================

								    NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/
