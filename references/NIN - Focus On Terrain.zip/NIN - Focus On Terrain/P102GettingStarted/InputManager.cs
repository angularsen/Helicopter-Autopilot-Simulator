/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the input manager class.
    /// </summary>
    public class InputManager
    {
        /// <summary>
        /// Keep track of the current game pad state.
        /// </summary>
        GamePadState _currentGamePadState;

        /// <summary>
        /// Keep track of the previous game pads states.
        /// </summary>
        GamePadState _previousGamePadState;

        /// <summary>
        /// Keep track of the current keyboard state.
        /// </summary>
        KeyboardState _currentKeyboardState;

        /// <summary>
        /// Keep track of the previous keyboard state.
        /// </summary>
        KeyboardState _previousKeyboardState;

        /// <summary>
        /// Keep track of the current mouse state.
        /// </summary>
        MouseState _currentMouseState;

        /// <summary>
        /// Keep track of the previous mouse state.
        /// </summary>
        MouseState _previousMouseState;

        /// <summary>
        /// Current game pad state.
        /// </summary>
        public GamePadState CurrentGamePadState
        {
            get
            {
                return _currentGamePadState;
            }
        }

        /// <summary>
        /// Previous game pad state.
        /// </summary>
        public GamePadState PreviousGamePadState
        {
            get
            {
                return _previousGamePadState;
            }
        }

        /// <summary>
        /// Current keyboard state.
        /// </summary>
        public KeyboardState CurrentKeyboardState
        {
            get
            {
                return _currentKeyboardState;
            }
        }

        /// <summary>
        /// Previous keyboard state.
        /// </summary>
        public KeyboardState PreviousKeyboardState
        {
            get
            {
                return _previousKeyboardState;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public InputManager()
        {
            _currentGamePadState = GamePad.GetState(PlayerIndex.One);
            _previousGamePadState = _currentGamePadState;

            _currentKeyboardState = Keyboard.GetState();
            _previousKeyboardState = _currentKeyboardState;

            _currentMouseState = Mouse.GetState();
            _previousMouseState = _currentMouseState;
        }

        /// <summary>
        /// Update the input devices.
        /// </summary>
        public void Update()
        {
            _previousGamePadState = _currentGamePadState;
            _currentGamePadState = GamePad.GetState(PlayerIndex.One);

            _previousKeyboardState = _currentKeyboardState;
            _currentKeyboardState = Keyboard.GetState();

            _previousMouseState = _currentMouseState;
            _currentMouseState = Mouse.GetState();
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/
