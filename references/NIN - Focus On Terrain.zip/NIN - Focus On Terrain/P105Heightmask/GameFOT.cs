/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the GameFOT class.
    /// </summary>
    public class GameFOT : Microsoft.Xna.Framework.Game
    {
        /// <summary>
        /// GameFOT class instance.
        /// </summary>
        static GameFOT _instance;

        /// <summary>
        /// Graphics device manager.
        /// </summary>
        GraphicsDeviceManager _graphicsManager;

        /// <summary>
        /// Input manager.
        /// </summary>
        InputManager _inputManager;

        /// <summary>
        /// Content manager.
        /// </summary>
        ContentManager _contentManager;

        /// <summary>
        /// Window aspect ratio.
        /// </summary>
        float _aspectRatio;

        /// <summary>
        /// Fly camera.
        /// </summary>
        FlyCamera _flyCamera;

        /// <summary>
        /// Terrain.
        /// </summary>
        Terrain _terrain;

        /// <summary>
        /// Return the instance of GameFOT.
        /// </summary>
        public static GameFOT Instance
        {
            get
            {
                return _instance;
            }
        }

        /// <summary>
        /// Graphics device.
        /// </summary>
        public GraphicsDevice GraphicsDevice
        {
            get
            {
                return _graphicsManager.GraphicsDevice;
            }
        }

        /// <summary>
        /// Aspect ratio.
        /// </summary>
        public float AspectRatio
        {
            get
            {
                return _aspectRatio;
            }
        }

        /// <summary>
        /// Content manager.
        /// </summary>
        public ContentManager ContentManager
        {
            get
            {
                return _contentManager;
            }
        }

        /// <summary>
        /// Input manager.
        /// </summary>
        public InputManager InputManager
        {
            get
            {
                return _inputManager;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public GameFOT()
        {
            _instance = this;

            this.Window.Title = "XNA - Focus on terrain - 105 Heightmask :. http://nerdy-inverse.com";

            _graphicsManager = new GraphicsDeviceManager(this);

            _graphicsManager.PreferredDepthStencilFormat = DepthFormat.Depth24Stencil8;

            _contentManager = new ContentManager(Services);

            _inputManager = new InputManager();

            InitializeScene();
        }

        /// <summary>
        /// Initialize scene.
        /// </summary>
        public void InitializeScene()
        {
            // Create the fly camera.
            _flyCamera = new FlyCamera();

            // We set the camera above the terrain.
            _flyCamera.Position = new Vector3(0.0f, 6.0f, 0.0f);
            _flyCamera.Rotation = new Vector3(0.5f, 0.0f, 0.0f);

            // Create a heightmask data for a four player terrain as an example.
            //
            // Here's the pattern:
            //
            //      0 0 0 0 0 0 0 0
            //      0 X X 0 0 X X 0
            //      0 X X 0 0 X X 0
            //      0 0 0 0 0 0 0 0
            //      0 0 0 0 0 0 0 0
            //      0 X X 0 0 X X 0
            //      0 X X 0 0 X X 0
            //      0 0 0 0 0 0 0 0
            int width = 32;
            int depth = 32;

            float min = 0.0f;
            float max = 3.0f;

            float maskedHeight = 0.0f;

            int startAreaWidth = 8;
            int startAreaDepth = 8;

            int offsetFromBorder = 2;

            bool[] maskData = new bool[width * depth];

            for (int z = 0; z < startAreaDepth; ++z)
            {
                for (int x = 0; x < startAreaWidth; ++x)
                {
                    // Top left corner.
                    maskData[(offsetFromBorder + x) + width * (offsetFromBorder + z)] = true;

                    // Top right corner.
                    maskData[(width - (offsetFromBorder + x)) + width * (offsetFromBorder + z)] = true;

                    // Bottom left corner.
                    maskData[(offsetFromBorder + x) + width * (depth - (offsetFromBorder + z))] = true;

                    // Bottom right corner.
                    maskData[(width - (offsetFromBorder + x)) + width * (depth - (offsetFromBorder + z))] = true;
                }
            }

            // Create the heightmask with our pattern.
            Heightmask heightmask = new Heightmask(width, depth, maskData);

            // Create a random heightmap using our mask.
            Heightmap heightmap = new Heightmap(width, depth, min, max, maskedHeight);

            // Set the heightmap heightmask.
            heightmap.Heightmask = heightmask;

            // Set the heightmap to use the heightmask.
            heightmap.UseHeightmask = true;

            // Generate a random heightmap using the heightmask.
            heightmap.GenerateRandomHeightmap();

            // Create the terrain.
            _terrain = new Terrain(heightmap);
        }

        /// <summary>
        /// Load the graphics content.
        /// </summary>
        /// <param name="loadAllContent"></param>
        protected override void LoadGraphicsContent(bool loadAllContent)
        {
            _aspectRatio = _graphicsManager.GraphicsDevice.Viewport.Width / (float)_graphicsManager.GraphicsDevice.Viewport.Height;

            if (loadAllContent)
            {
                _terrain.LoadGraphicsContent();
            }
        }

        /// <summary>
        /// Unload the graphics content.
        /// </summary>
        /// <param name="unloadAllContent"></param>
        protected override void UnloadGraphicsContent(bool unloadAllContent)
        {
            if (unloadAllContent)
            {
                _contentManager.Unload();
            }
        }

        /// <summary>
        /// Update the game.
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Update(GameTime gameTime)
        {
            _inputManager.Update();

            if (_inputManager.CurrentGamePadState.Buttons.Back == ButtonState.Pressed ||
                _inputManager.CurrentKeyboardState.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }

            if ((_inputManager.CurrentGamePadState.Buttons.A == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.A == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.Space) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.Space)))
            {
                _terrain.IsWireframe = !_terrain.IsWireframe;
            }

            if ((_inputManager.CurrentGamePadState.Buttons.B == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.B == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.Enter) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.Enter)))
            {
                _terrain.Heightmap.GenerateRandomHeightmap();
                _terrain.BuildTerrainMesh();
            }

            if ((_inputManager.CurrentGamePadState.Buttons.X == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.X == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.PageDown) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.PageDown)))
            {
                _terrain.SaveToFile("terrain.raw");
            }

            if ((_inputManager.CurrentGamePadState.Buttons.Y == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.Y == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.PageUp) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.PageUp)))
            {
                _terrain.LoadFromFile("terrain.raw");
            }

            if ((_inputManager.CurrentGamePadState.Buttons.RightShoulder == ButtonState.Pressed &&
                _inputManager.PreviousGamePadState.Buttons.RightShoulder == ButtonState.Released) ||
                (_inputManager.CurrentKeyboardState.IsKeyDown(Keys.Back) &&
                _inputManager.PreviousKeyboardState.IsKeyUp(Keys.Back)))
            {
                _terrain.Heightmap.UseHeightmask = !_terrain.Heightmap.UseHeightmask;
            }

            _flyCamera.Update(gameTime);

            base.Update(gameTime);
        }

        /// <summary>
        /// Draw the game.
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Draw(GameTime gameTime)
        {
            _graphicsManager.GraphicsDevice.Clear(Color.CornflowerBlue);

            _terrain.Draw(gameTime, _flyCamera.View, _flyCamera.Projection);

            base.Draw(gameTime);
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/
