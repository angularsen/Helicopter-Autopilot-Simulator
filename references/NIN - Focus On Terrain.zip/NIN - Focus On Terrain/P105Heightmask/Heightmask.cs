/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the heightmask class.
    /// </summary>
    public class Heightmask
    {
        /// <summary>
        /// Width of the heightmask.
        /// </summary>
        int _width;

        /// <summary>
        /// Depth of the heightmask.
        /// </summary>
        int _depth;

        /// <summary>
        /// Mask values of the heightmask.
        /// </summary>
        bool[] _maskValues;

        /// <summary>
        /// Get the width of the heightmask.
        /// </summary>
        public int Width
        {
            get
            {
                return _width;
            }
        }

        /// <summary>
        /// Get the depth of the heightmask.
        /// </summary>
        public int Depth
        {
            get
            {
                return _depth;
            }
        }

        /// <summary>
        /// Mask values of the heightmask.
        /// </summary>
        public bool[] MaskValues
        {
            get
            {
                return _maskValues;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="width"></param>
        /// <param name="depth"></param>
        public Heightmask(int width, int depth)
        {
            _width = width;
            _depth = depth;

            _maskValues = new bool[_width * _depth];
        }

        /// <summary>
        /// This constructor builds a heightmask using the boolean array.
        /// </summary>
        /// <param name="width"></param>
        /// <param name="depth"></param>
        /// <param name="data"></param>
        public Heightmask(int width, int depth, bool[] data)
        {
            _width = width;
            _depth = depth;

            _maskValues = (bool[])data.Clone();
        }

        /// <summary>
        /// Return the mask value at the given x,z coordinate.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <returns></returns>
        public bool GetMaskValue(int x, int z)
        {
            return _maskValues[x + z * _width];
        }

        /// <summary>
        /// Set the mask value at the given x,z coordinate.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <param name="value"></param>
        public void SetMaskValue(int x, int z, bool value)
        {
            _maskValues[x + z * _width] = value;
        }

        /// <summary>
        /// Save a heightmask to a file.
        /// </summary>
        /// <param name="filename"></param>
        public void SaveToFile(String filename)
        {
            try
            {
                FileStream stream = File.Open(filename, FileMode.OpenOrCreate);

                if (stream != null)
                {
                    BinaryWriter writer = new BinaryWriter(stream);

                    writer.Write(_width);
                    writer.Write(_depth);

                    for (int i = 0; i < _maskValues.Length; ++i)
                    {
                        writer.Write(_maskValues[i]);
                    }

                    writer.Flush();

                    stream.Close();
                }
            }
            catch (Exception)
            {

            }
        }

        /// <summary>
        /// Load a heightmask from a file.
        /// </summary>
        /// <param name="filename"></param>
        public void LoadFromFile(String filename)
        {
            try
            {
                FileStream stream = File.Open(filename, FileMode.Open);

                BinaryReader reader = new BinaryReader(stream);

                _width = reader.ReadInt32();
                _depth = reader.ReadInt32();

                _maskValues = new bool[_width * _depth];

                for (int i = 0; i < _maskValues.Length; ++i)
                {
                    _maskValues[i] = reader.ReadBoolean();
                }

                reader.Close();

                stream.Close();
            }
            catch (Exception)
            {

            }
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/