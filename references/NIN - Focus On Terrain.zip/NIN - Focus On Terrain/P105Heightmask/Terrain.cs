/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the terrain class.
    /// </summary>
    public class Terrain
    {
        /// <summary>
        /// Heightmap used to generate the terrain mesh.
        /// </summary>
        Heightmap _heightmap;

        /// <summary>
        /// Terrain mesh geometry.
        /// </summary>
        VertexPositionColor[] _geometry;

        /// <summary>
        /// Terrain mesh indices.
        /// </summary>
        short[] _indices;

        /// <summary>
        /// Vertex buffer of the terrain mesh.
        /// </summary>
        VertexBuffer _vertexBuffer;

        /// <summary>
        /// Index buffer of the terrain mesh.
        /// </summary>
        IndexBuffer _indexBuffer;

        /// <summary>
        /// Vertex declaration of the terrain mesh.
        /// </summary>
        VertexDeclaration _vertexDeclaration;

        /// <summary>
        /// Primitive type used by the terrain mesh.
        /// </summary>
        PrimitiveType _primitiveType;

        /// <summary>
        /// Terrain effect shader.
        /// </summary>
        Effect _effect;

        /// <summary>
        /// World matrix.
        /// </summary>
        Matrix _worldMatrix;

        /// <summary>
        /// Wireframe fill mode flag.
        /// </summary>
        bool _isWireframe;

        /// <summary>
        /// Get or set the wireframe fill mode.
        /// </summary>
        public bool IsWireframe
        {
            get
            {
                return _isWireframe;
            }
            set
            {
                _isWireframe = value;
            }
        }

        /// <summary>
        /// The heightmap used by the terrain.
        /// </summary>
        public Heightmap Heightmap
        {
            get
            {
                return _heightmap;
            }
            set
            {
                _heightmap = value;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="heightmap"></param>
        public Terrain(Heightmap heightmap)
        {
            _heightmap = heightmap;
        }

        /// <summary>
        /// Load the graphics content and also build the mesh.
        /// </summary>
        public void LoadGraphicsContent()
        {
            _effect = GameFOT.Instance.ContentManager.Load<Effect>("Content/Effects/TerrainEffect");

            _effect.CurrentTechnique = _effect.Techniques["DefaultTechnique"];

            BuildTerrainMesh();
        }

        /// <summary>
        /// Draw the terrain.
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="viewMatrix"></param>
        /// <param name="projectionMatrix"></param>
        public void Draw(GameTime gameTime, Matrix viewMatrix, Matrix projectionMatrix)
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            int primitivePerStrip = (depth - 1) * 2;
            int stripCount = width - 1;
            int vertexPerStrip = depth * 2;

            if (_isWireframe)
            {
                GameFOT.Instance.GraphicsDevice.RenderState.FillMode = FillMode.WireFrame;
            }
            else
            {
                GameFOT.Instance.GraphicsDevice.RenderState.FillMode = FillMode.Solid;
            }

            GameFOT.Instance.GraphicsDevice.RenderState.DepthBufferEnable = true;
            GameFOT.Instance.GraphicsDevice.RenderState.DepthBufferWriteEnable = true;

            Matrix worldViewProjection = _worldMatrix * viewMatrix * projectionMatrix;

            GameFOT.Instance.GraphicsDevice.VertexDeclaration = _vertexDeclaration;

            _effect.Parameters["g_matWorldViewProjection"].SetValue(worldViewProjection);

            _effect.Begin();

            for (int s = 0; s < stripCount; ++s)
            {
                foreach (EffectPass pass in _effect.CurrentTechnique.Passes)
                {
                    pass.Begin();

                    GameFOT.Instance.GraphicsDevice.Vertices[0].SetSource(_vertexBuffer, 0, VertexPositionColor.SizeInBytes);

                    GameFOT.Instance.GraphicsDevice.Indices = _indexBuffer;

                    GameFOT.Instance.GraphicsDevice.DrawIndexedPrimitives(_primitiveType, 0, 0, _geometry.Length, vertexPerStrip * s, primitivePerStrip);

                    pass.End();
                }
            }
            
            _effect.End();
        }

        /// <summary>
        /// Build the vertex buffer of the terrain mesh.
        /// </summary>
        private void BuildVertexBuffer()
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            _worldMatrix = Matrix.CreateTranslation((float)width * -0.5f, 0.0f, (float)depth * -0.5f);

            int index = 0;

            Vector3 position;
            Color color;

            _geometry = new VertexPositionColor[width * depth];

            for (int z = 0; z < depth; ++z)
            {
                for (int x = 0; x < width; ++x)
                {
                    position = new Vector3((float)x, _heightmap.GetHeightValue(x, z), (float)z);

                    float c = _heightmap.GetHeightPercentage(x, z);

                    color = new Color(new Vector3(c, 1.0f, c));

                    _geometry[index] = new VertexPositionColor(position, color);

                    ++index;
                }
            }
        }

        /// <summary>
        /// Build the index buffer of the terrain mesh.
        /// </summary>
        private void BuildIndexBuffer()
        {
            int width = _heightmap.Width;
            int depth = _heightmap.Depth;

            int stripLength = 4 + (depth - 2) * 2;
            int stripCount = width - 1;

            _indices = new short[stripLength * stripCount];

            int index = 0;

            for (int s = 0; s < stripCount; ++s)
            {
                for (int z = 0; z < depth; ++z)
                {
                    _indices[index] = (short)(s + depth * z);

                    ++index;

                    _indices[index] = (short)(s + depth * z + 1);

                    ++index;
                }
            }
        }

        /// <summary>
        /// Rebuild the terrain mesh.
        /// </summary>
        public void BuildTerrainMesh()
        {
            BuildVertexBuffer();

            _primitiveType = PrimitiveType.TriangleStrip;

            _vertexDeclaration = new VertexDeclaration(GameFOT.Instance.GraphicsDevice, VertexPositionColor.VertexElements);

            _vertexBuffer = new VertexBuffer(GameFOT.Instance.GraphicsDevice, VertexPositionColor.SizeInBytes * _geometry.Length, ResourceUsage.WriteOnly, ResourceManagementMode.Automatic);

            _vertexBuffer.SetData<VertexPositionColor>(_geometry);

            BuildIndexBuffer();

            _indexBuffer = new IndexBuffer(GameFOT.Instance.GraphicsDevice, sizeof(short) * _indices.Length, ResourceUsage.WriteOnly, IndexElementSize.SixteenBits);

            _indexBuffer.SetData<short>(_indices);
        }

        /// <summary>
        /// Save the terrain to a file.
        /// </summary>
        /// <param name="filename"></param>
        public void SaveToFile(String filename)
        {
            _heightmap.SaveToFile(filename);
        }

        /// <summary>
        /// Load the terrain from a file and rebuild the terrain mesh.
        /// </summary>
        /// <param name="filename"></param>
        public void LoadFromFile(String filename)
        {
            _heightmap.LoadFromFile(filename);

            BuildTerrainMesh();
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/