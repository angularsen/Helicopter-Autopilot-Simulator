/*======================================================================================================================

	                      ::::    ::: :::::::::: :::::::::  :::::::::  :::   ::: 
	                     :+:+:   :+: :+:        :+:    :+: :+:    :+: :+:   :+:  
	                    :+:+:+  +:+ +:+        +:+    +:+ +:+    +:+  +:+ +:+    
                       +#+ +:+ +#+ +#++:++#   +#++:++#:  +#+    +:+   +#++:      
                      +#+  +#+#+# +#+        +#+    +#+ +#+    +#+    +#+        
                     #+#   #+#+# #+#        #+#    #+# #+#    #+#    #+#         
                    ###    #### ########## ###    ### #########     ###          
						  ::::::::::: ::::    ::: :::     ::: :::::::::: :::::::::   ::::::::  :::::::::: 
							 :+:     :+:+:   :+: :+:     :+: :+:        :+:    :+: :+:    :+: :+:         
							+:+     :+:+:+  +:+ +:+     +:+ +:+        +:+    +:+ +:+        +:+          
						   +#+     +#+ +:+ +#+ +#+     +:+ +#++:++#   +#++:++#:  +#++:++#++ +#++:++#      
						  +#+     +#+  +#+#+#  +#+   +#+  +#+        +#+    +#+        +#+ +#+            
						 #+#     #+#   #+#+#   #+#+#+#   #+#        #+#    #+# #+#    #+# #+#             
					########### ###    ####     ###     ########## ###    ###  ########  ##########  

======================================================================================================================*/

/*======================================================================================================================

	This source code is released under my lovely "I don't care" license. 
	
	This software is provided 'as-is', without any express or implied warranty. In no event will the author be held 
	liable for any damages arising from the use of this software. Anyway, feel free to give me some feedback.

======================================================================================================================*/

#region Using Statements
using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace NINFocusOnTerrain
{
    /// <summary>
    /// This is the terrain patch class.
    /// </summary>
    public class TerrainPatch
    {
        /// <summary>
        /// Bounding box used for this patch.
        /// </summary>
        BoundingBox _boundingBox;

        /// <summary>
        /// Geometry of the terrain patch.
        /// </summary>
        VertexPositionNormalTexture[] _geometry;

        /// <summary>
        /// Indices of the terrain patch.
        /// </summary>
        short[] _indices;

        /// <summary>
        /// Vertex buffer of the terrain patch.
        /// </summary>
        VertexBuffer _vertexBuffer;

        /// <summary>
        /// Index buffer of the terrain patch.
        /// </summary>
        IndexBuffer _indexBuffer;

        /// <summary>
        /// Width of the terrain patch.
        /// </summary>
        int _width;

        /// <summary>
        /// Depth of the terrain patch.
        /// </summary>
        int _depth;

        /// <summary>
        /// X offset used when we retrieve the heigth values from the heightmap.
        /// </summary>
        int _offsetX;

        /// <summary>
        /// Y offset used when we retrieve the height values from the heightmap.
        /// </summary>
        int _offsetZ;

        /// <summary>
        /// Get the bounding box.
        /// </summary>
        public BoundingBox BoundingBox
        {
            get
            {
                return _boundingBox;
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public TerrainPatch()
        {
            _boundingBox = new BoundingBox();
        }

        /// <summary>
        /// Build a terrain patch.
        /// </summary>
        /// <param name="heightmap"></param>
        /// <param name="worldMatrix"></param>
        /// <param name="width"></param>
        /// <param name="depth"></param>
        /// <param name="offsetX"></param>
        /// <param name="offsetZ"></param>
        public void BuildPatch(Heightmap heightmap, Matrix worldMatrix, int width, int depth, int offsetX, int offsetZ)
        {
            _width = width;
            _depth = depth;

            _offsetX = offsetX;
            _offsetZ = offsetZ;

            _boundingBox.Min.X = offsetX;
            _boundingBox.Min.Z = offsetZ;

            _boundingBox.Max.X = offsetX + width;
            _boundingBox.Max.Z = offsetZ + depth;

            BuildVertexBuffer(heightmap);

            _vertexBuffer = new VertexBuffer(GameFOT.Instance.GraphicsDevice, VertexPositionNormalTexture.SizeInBytes * _geometry.Length, ResourceUsage.WriteOnly, ResourceManagementMode.Automatic);

            _vertexBuffer.SetData<VertexPositionNormalTexture>(_geometry);

            BuildIndexBuffer();

            _indexBuffer = new IndexBuffer(GameFOT.Instance.GraphicsDevice, sizeof(short) * _indices.Length, ResourceUsage.WriteOnly, IndexElementSize.SixteenBits);

            _indexBuffer.SetData<short>(_indices);

            // Apply the world matrix transformation to the bounding box.
            _boundingBox.Min = Vector3.Transform(_boundingBox.Min, worldMatrix);
            _boundingBox.Max = Vector3.Transform(_boundingBox.Max, worldMatrix);
        }

        /// <summary>
        /// Build the vertex buffer as well as the bounding box.
        /// </summary>
        /// <param name="heightmap"></param>
        private void BuildVertexBuffer(Heightmap heightmap)
        {
            int index = 0;

            Vector3 position;
            Vector3 normal;

            _boundingBox.Min.Y = float.MaxValue;

            _boundingBox.Max.Y = float.MinValue;

            _geometry = new VertexPositionNormalTexture[_width * _depth];

            for (int z = _offsetZ; z < _offsetZ + _depth; ++z)
            {
                for (int x = _offsetX; x < _offsetX + _width; ++x)
                {
                    float height = heightmap.GetHeightValue(x, z);

                    if (height < _boundingBox.Min.Y)
                    {
                        _boundingBox.Min.Y = height;
                    }

                    if (height > _boundingBox.Max.Y)
                    {
                        _boundingBox.Max.Y = height;
                    }

                    position = new Vector3((float)x, height, (float)z);

                    ComputeVertexNormal(heightmap, x, z, out normal);

                    _geometry[index] = new VertexPositionNormalTexture(position, normal, new Vector2(x, z));

                    ++index;
                }
            }
        }

        /// <summary>
        /// Build the index buffer.
        /// </summary>
        private void BuildIndexBuffer()
        {
            int stripLength = 4 + (_depth - 2) * 2;
            int stripCount = _width - 1;

            _indices = new short[stripLength * stripCount];

            int index = 0;

            for (int s = 0; s < stripCount; ++s)
            {
                for (int z = 0; z < _depth; ++z)
                {
                    _indices[index] = (short)(s + _depth * z);

                    ++index;

                    _indices[index] = (short)(s + _depth * z + 1);

                    ++index;
                }
            }
        }

        /// <summary>
        /// Compute vertex normal at the given x,z coordinate.
        /// </summary>
        /// <param name="heightmap"></param>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <param name="normal"></param>
        private void ComputeVertexNormal(Heightmap heightmap, int x, int z, out Vector3 normal)
        {
            int width = heightmap.Width;
            int depth = heightmap.Depth;

            Vector3 center;
            Vector3 p1;
            Vector3 p2;
            Vector3 avgNormal = Vector3.Zero;

            int avgCount = 0;

            bool spaceAbove = false;
            bool spaceBelow = false;
            bool spaceLeft = false;
            bool spaceRight = false;

            Vector3 tmpNormal;
            Vector3 v1;
            Vector3 v2;

            center = new Vector3((float)x, heightmap.GetHeightValue(x, z), (float)z);

            if (x > 0)
            {
                spaceLeft = true;
            }

            if (x < width - 1)
            {
                spaceRight = true;
            }

            if (z > 0)
            {
                spaceAbove = true;
            }

            if (z < depth - 1)
            {
                spaceBelow = true;
            }

            if (spaceAbove && spaceLeft)
            {
                p1 = new Vector3(x - 1, heightmap.GetHeightValue(x - 1, z), z);
                p2 = new Vector3(x - 1, heightmap.GetHeightValue(x - 1, z - 1), z - 1);

                v1 = p1 - center;
                v2 = p2 - p1;

                tmpNormal = Vector3.Cross(v1, v2);
                avgNormal += tmpNormal;

                ++avgCount;
            }

            if (spaceAbove && spaceRight)
            {
                p1 = new Vector3(x, heightmap.GetHeightValue(x, z - 1), z - 1);
                p2 = new Vector3(x + 1, heightmap.GetHeightValue(x + 1, z - 1), z - 1);

                v1 = p1 - center;
                v2 = p2 - p1;

                tmpNormal = Vector3.Cross(v1, v2);
                avgNormal += tmpNormal;

                ++avgCount;
            }

            if (spaceBelow && spaceRight)
            {
                p1 = new Vector3(x + 1, heightmap.GetHeightValue(x + 1, z), z);
                p2 = new Vector3(x + 1, heightmap.GetHeightValue(x + 1, z + 1), z + 1);

                v1 = p1 - center;
                v2 = p2 - p1;

                tmpNormal = Vector3.Cross(v1, v2);
                avgNormal += tmpNormal;

                ++avgCount;
            }

            if (spaceBelow && spaceLeft)
            {
                p1 = new Vector3(x, heightmap.GetHeightValue(x, z + 1), z + 1);
                p2 = new Vector3(x - 1, heightmap.GetHeightValue(x - 1, z + 1), z + 1);

                v1 = p1 - center;
                v2 = p2 - p1;

                tmpNormal = Vector3.Cross(v1, v2);
                avgNormal += tmpNormal;

                ++avgCount;
            }

            normal = avgNormal / avgCount;
        }

        /// <summary>
        /// Draw the terrain patch.
        /// </summary>
        public void Draw()
        {
            int primitivePerStrip = (_depth - 1) * 2;
            int stripCount = _width - 1;
            int vertexPerStrip = _depth * 2;

            for (int s = 0; s < stripCount; ++s)
            {
                GameFOT.Instance.GraphicsDevice.Vertices[0].SetSource(_vertexBuffer, 0, VertexPositionNormalTexture.SizeInBytes);

                GameFOT.Instance.GraphicsDevice.Indices = _indexBuffer;

                GameFOT.Instance.GraphicsDevice.DrawIndexedPrimitives(PrimitiveType.TriangleStrip, 0, 0, _geometry.Length, vertexPerStrip * s, primitivePerStrip);
            }
        }
    }
}

/*======================================================================================================================

									NIN - Nerdy Inverse Network - http://nerdy-inverse.com

======================================================================================================================*/
