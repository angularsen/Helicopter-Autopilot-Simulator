namespace TestXBAP
{
	/// <summary>
	/// Interaction logic for Page1.xaml
	/// </summary>

	public partial class Page1
	{

		public Page1()
		{
			InitializeComponent();
		}

	}
}