/*
Copyright (c) 2007, John Stewien (formerly of Swordfish Computing Australia)

All rights reserved. Modified BSD License (removed some restrictions):

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.

Redistributions in binary form must retain the string:
"Swordfish Charts, Copyright (c) 2007, John Stewien"
in the XYLineChart.xaml.cs file.

Neither the name of Swordfish Charts nor the names of its contributors may be
used to endorse or promote products derived from this software without specific
prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

using System;
using System.Globalization;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;

namespace Swordfish.WPF.Charts
{
	public class AdornerCursorCoordinateDrawer : Adorner
	{
		// ********************************************************************
		// Private Fields
		// ********************************************************************
		#region Private Fields
		/// <summary>
		/// Flag indicating if the coordinates are locked to the closest point or or not.
		/// </summary>
		private bool locked;
		/// <summary>
		/// The transformed coordinate of the lock point
		/// </summary>
		private Point lockPoint;
		/// <summary>
		/// The cursor position. Used for calculating the relative position of the text.
		/// </summary>
		private Point mousePoint;
		/// <summary>
		/// The transform of the element being adorned
		/// </summary>
		private readonly MatrixTransform elementTransform;

        private bool flipYAxis = false;

		#endregion Private Fields

		// ********************************************************************
		// Public Methods
		// ********************************************************************
		#region Public Methods

		/// <summary>
		/// Constructor. Initializes class fields.
		/// </summary>
		public AdornerCursorCoordinateDrawer(UIElement adornedElement, MatrixTransform shapeTransform)
			: base(adornedElement)
		{
			elementTransform = shapeTransform;
			IsHitTestVisible = false;
		}

		/// <summary>
		/// Draws a mouse cursor on the adorened element
		/// </summary>
		/// <param name="drawingContext"></param>
		protected override void OnRender(DrawingContext drawingContext)
		{
			GeneralTransform inverse = elementTransform.Inverse;
			if (inverse == null)
				return;

			Brush blackBrush = new SolidColorBrush(Colors.Black);

			float radius = 15;
			if (locked)
			{
				// Draw the little circle around the lock point

				Point point = elementTransform.Transform(lockPoint);
				drawingContext.DrawEllipse(null, new Pen(blackBrush, 3), point, 2.5, 2.5);
				drawingContext.DrawEllipse(null, new Pen(new SolidColorBrush(Colors.White), 2), point, 2.5, 2.5);

				// Draw the big yellow circle

				Pen yellowPen = new Pen(new SolidColorBrush(Colors.Yellow), 2);
				Pen blackPen = new Pen(blackBrush, 3);
				drawingContext.DrawEllipse(null, blackPen, mousePoint, radius, radius);
				drawingContext.DrawEllipse(null, yellowPen, mousePoint, radius, radius);
			}
			else
			{
				// Draw the target symbol

				Pen blackPen = new Pen(blackBrush, .7);
				drawingContext.DrawEllipse(null, blackPen, mousePoint, radius, radius);
				drawingContext.DrawLine(blackPen, new Point(mousePoint.X - radius * 1.6, mousePoint.Y), new Point(mousePoint.X - 2, mousePoint.Y));
				drawingContext.DrawLine(blackPen, new Point(mousePoint.X + radius * 1.6, mousePoint.Y), new Point(mousePoint.X + 2, mousePoint.Y));
				drawingContext.DrawLine(blackPen, new Point(mousePoint.X, mousePoint.Y - radius * 1.6), new Point(mousePoint.X, mousePoint.Y - 2));
				drawingContext.DrawLine(blackPen, new Point(mousePoint.X, mousePoint.Y + radius * 1.6), new Point(mousePoint.X, mousePoint.Y + 2));
			}

			// Draw the coordinate text

			// Works out the number of decimal places required to show the difference between
			// 2 pixels. E.g if pixels are .1 apart then use 2 places etc
			Rect rect = inverse.TransformBounds(new Rect(0, 0, 1, 1));

			int xFigures = Math.Max(1, (int)(Math.Ceiling(-Math.Log10(rect.Width)) + .1));
			int yFigures = Math.Max(1, (int)(Math.Ceiling(-Math.Log10(rect.Height)) + .1));

			// Number of significant figures for the x coordinate
			string xFormat = "#0." + new string('#', xFigures);
			/// Number of significant figures for the y coordinate
			string yFormat = "#0." + new string('#', yFigures);

			Point coordinate = locked ? lockPoint : inverse.Transform(mousePoint);

			string coordinateText = coordinate.X.ToString(xFormat) + "," + coordinate.Y.ToString(yFormat);

            if (flipYAxis)
                drawingContext.PushTransform(new ScaleTransform(1, 1));
            else
                drawingContext.PushTransform(new ScaleTransform(1, -1));

            FormattedText formattedText = new FormattedText(coordinateText, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, new Typeface("Arial"), 10, blackBrush);
			Pen textBoxPen = new Pen(new SolidColorBrush(Color.FromArgb(127, 255, 255, 255)), 1);

			Rect textBoxRect = flipYAxis ?
                new Rect(new Point(mousePoint.X + radius * .7, mousePoint.Y + radius * .7), new Size(formattedText.Width, formattedText.Height)):
                new Rect(new Point(mousePoint.X + radius * .7, -mousePoint.Y + radius * .7), new Size(formattedText.Width, formattedText.Height));

            double diff = textBoxRect.Right + 3 - ((FrameworkElement)AdornedElement).ActualWidth;

			if (diff > 0)
				textBoxRect.Location = new Point(textBoxRect.Left - diff, textBoxRect.Top);

			drawingContext.DrawRectangle(textBoxPen.Brush, textBoxPen, textBoxRect);
			drawingContext.DrawText(formattedText, textBoxRect.Location);
			drawingContext.Pop();
		}

		#endregion Public Methods
	
		// ********************************************************************
		// Properties
		// ********************************************************************
		#region Properties

		/// <summary>
		/// Gets/Sets if the coordinates are locked to the LockPoint or not
		/// </summary>
		public bool Locked
		{
			get
			{
				return locked;
			}
			set
			{
				if (locked != value)
				{
					locked = value;
					AdornerLayer parent = AdornerLayer.GetAdornerLayer(AdornedElement);
					parent.Update();
				}
			}
		}

		/// <summary>
		/// Gets/Sets the coordinate for the cursor to show when it is "Locked"
		/// </summary>
		public Point LockPoint
		{
			get
			{
				return lockPoint;
			}
			set
			{
				if (lockPoint != value)
				{
					lockPoint = value;
					AdornerLayer parent = AdornerLayer.GetAdornerLayer(AdornedElement);
					parent.Update();
				}
			}
		}

		/// <summary>
		/// Gets/Sets the current mouse position
		/// </summary>
		public Point MousePoint
		{
			get
			{
				return mousePoint;
			}
			set
			{
				if (mousePoint != value)
				{
					mousePoint = value;
					AdornerLayer parent = AdornerLayer.GetAdornerLayer(AdornedElement);
					parent.Update();
				}
			}
		}

        /// <summary>
        /// Gets/Sets whether to flip the Y axis or not
        /// </summary>
        public bool FlipYAxis
        {
            get
            {
                return flipYAxis;
            }
            set
            {
                if (flipYAxis != value)
                {
                    flipYAxis = value;
                    this.InvalidateVisual();
                }
            }
        }

		#endregion Properties

	}
}
