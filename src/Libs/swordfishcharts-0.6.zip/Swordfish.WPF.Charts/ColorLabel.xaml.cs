/*
Copyright (c) 2007, John Stewien (formerly of Swordfish Computing Australia)

All rights reserved. Modified BSD License (removed some restrictions):

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.

Redistributions in binary form must retain the string:
"Swordfish Charts, Copyright (c) 2007, John Stewien"
in the XYLineChart.xaml.cs file.

Neither the name of Swordfish Charts nor the names of its contributors may be
used to endorse or promote products derived from this software without specific
prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

using System.Windows;
using System.Windows.Media;

namespace Swordfish.WPF.Charts
{
	/// <summary>
	/// Interaction logic for ColorLabel.xaml
	/// </summary>
	public partial class ColorLabel
	{
		// ********************************************************************
		// Constructors
		// ********************************************************************
		#region Constructors

		/// <summary>
		/// Constructor. Initializes class fields.
		/// </summary>
		public ColorLabel()
		{
			InitializeComponent();
			Background = new SolidColorBrush(Colors.Transparent);
		}

		/// <summary>
		/// Initializes the text and color properties.
		/// </summary>
		/// <param name="text"></param>
		/// <param name="color"></param>
		public ColorLabel(string text, Color color) : this()
		{
			Text = text;
			Color = color;
		}

		#endregion Constructors

		// ********************************************************************
		// DependencyProperties
		// ********************************************************************
		#region DependencyProperties

		// Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty TextProperty =
			DependencyProperty.Register("Text", typeof(string), typeof(ColorLabel), new UIPropertyMetadata("Blank", UpdateText));

		// Using a DependencyProperty as the backing store for Color.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty ColorProperty =
			DependencyProperty.Register("Color", typeof(Color), typeof(ColorLabel), new UIPropertyMetadata(Colors.Violet, UpdateColor));

		#endregion DependencyProperties

		// ********************************************************************
		// Properties
		// ********************************************************************
		#region Properties

		/// <summary>
		/// Gets/Sets the text of the color label
		/// </summary>
		public string Text
		{
			get
			{
				return (string)GetValue(TextProperty);
			}
			set
			{
				SetValue(TextProperty, value);
			}
		}

		/// <summary>
		/// Gets/Sets the color to be displayed
		/// </summary>
		public Color Color
		{
			get
			{
				return (Color)GetValue(ColorProperty);
			}
			set
			{
				SetValue(ColorProperty, value);
			}
		}

		#endregion Properties

		// ********************************************************************
		// Event Handlers
		// ********************************************************************
		#region Event Handlers

		/// <summary>
		/// Handles when the Color property is changed
		/// </summary>
		/// <param name="dependency"></param>
		/// <param name="e"></param>
		protected static void UpdateColor(DependencyObject dependency, DependencyPropertyChangedEventArgs e)
		{
			ColorLabel colorLabel = (ColorLabel)dependency;
			Color newColor = (Color)e.NewValue;
			colorLabel.color.Color = newColor;
			/*
			if (newColor == Colors.Transparent)
				colorLabel.colorSize.Visibility = Visibility.Collapsed;
			else
				colorLabel.colorSize.Visibility = Visibility.Visible;
			*/
		}

		/// <summary>
		/// Handles when the Text property is changed
		/// </summary>
		/// <param name="dependency"></param>
		/// <param name="e"></param>
		protected static void UpdateText(DependencyObject dependency, DependencyPropertyChangedEventArgs e)
		{
			ColorLabel colorLabel = (ColorLabel)dependency;
			colorLabel.textBlock.Text = (string)e.NewValue;
			colorLabel.textBlock.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity)); 
			colorLabel.colorSize.Width = colorLabel.textBlock.DesiredSize.Height * 1.5;
		}

		#endregion Event Handlers
	}
}