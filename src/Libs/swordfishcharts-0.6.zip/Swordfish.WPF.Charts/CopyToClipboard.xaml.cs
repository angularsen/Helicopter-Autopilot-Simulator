/*
Copyright (c) 2007, John Stewien (formerly of Swordfish Computing Australia)

All rights reserved. Modified BSD License (removed some restrictions):

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.

Redistributions in binary form must retain the string:
"Swordfish Charts, Copyright (c) 2007, John Stewien"
in the XYLineChart.xaml.cs file.

Neither the name of Swordfish Charts nor the names of its contributors may be
used to endorse or promote products derived from this software without specific
prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

using System;
using System.Windows;
using System.Windows.Input;

namespace Swordfish.WPF.Charts
{
	/// <summary>
	/// Interaction logic for UIElementToClipboard.xaml
	/// </summary>

	public partial class CopyToClipboard
	{
		public delegate void CopyToClipboardDelegateType(FrameworkElement target, double width, double height);

		public CopyToClipboardDelegateType CopyToClipboardDelegate;
		public CopyToClipboardDelegateType SaveToFileDelegate;

		public CopyToClipboard()
		{
			InitializeComponent();
			copyOptions.Visibility = Visibility.Collapsed;
			MouseEnter += UIElementToClipboard_MouseEnter;
			MouseLeave += UIElementToClipboard_MouseLeave;
			CopyToClipboardDelegate = ChartUtilities.CopyFrameworkElementToClipboard;
		}

		// Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty CopyTargetProperty =
			DependencyProperty.Register("CopyTarget", typeof(FrameworkElement), typeof(CopyToClipboard), new UIPropertyMetadata(null));

		public FrameworkElement CopyTarget
		{
			get
			{
				return (FrameworkElement)GetValue(CopyTargetProperty);
			}
			set
			{
				SetValue(CopyTargetProperty, value);
			}
		}

		void OnCopyToClipboard(double width, double height)
		{
            try
            {
                if (saveToFile.IsChecked == true)
                {
                    SaveToFileDelegate(CopyTarget, width, height);
                }
                else
                {
                    CopyToClipboardDelegate(CopyTarget, width, height);
                }
            }
            catch (Exception)
            {
            }
		}

		void UIElementToClipboard_MouseLeave(object sender, MouseEventArgs e)
		{
			copyOptions.Visibility = Visibility.Collapsed;
			Margin = new Thickness(0, 0, 0, 0);
		}

		void UIElementToClipboard_MouseEnter(object sender, MouseEventArgs e)
		{
			copyOptions.Visibility = Visibility.Visible;
			Margin = new Thickness(0, 0, 0, 8);
		}

		void bCopy640x480_Click(object sender, RoutedEventArgs e)
		{
			OnCopyToClipboard(640, 480);
		}
		void bCopy800x600_Click(object sender, RoutedEventArgs e)
		{
			OnCopyToClipboard(800, 600);
		}
		void bCopy1024x768_Click(object sender, RoutedEventArgs e)
		{
			OnCopyToClipboard(1024, 768);
		}
		void bCopy1280x1024_Click(object sender, RoutedEventArgs e)
		{
			OnCopyToClipboard(1280, 1024);
		}
		void bCopyCustom_Click(object sender, RoutedEventArgs e)
		{
			double width;
			double height;
			Double.TryParse(tbWidth.Text, out width);
			Double.TryParse(tbHeight.Text, out height);
			OnCopyToClipboard(width, height);
		}
	}
}