/*
Copyright (c) 2007, John Stewien (formerly of Swordfish Computing Australia)

All rights reserved. Modified BSD License (removed some restrictions):

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.

Redistributions in binary form must retain the string:
"Swordfish Charts, Copyright (c) 2007, John Stewien"
in the XYLineChart.xaml.cs file.

Neither the name of Swordfish Charts nor the names of its contributors may be
used to endorse or promote products derived from this software without specific
prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

using System;
using System.Windows;
using System.Windows.Controls;

namespace Swordfish.WPF.Charts
{
	/// <summary>
	/// ========================================
	/// WPF Custom Control
	/// ========================================
	///
	/// Follow steps 1a or 1b and then 2 to use this custom control in a XAML file.
	///
	/// Step 1a) Using this custom control in a XAML file that exists in the current project.
	/// Add this XmlNamespace attribute to the root element of the markup file where it is 
	/// to be used:
	///
	///     xmlns:MyNamespace="clr-namespace:Swordfish.WPF.Controls"
	///
	///
	/// Step 1b) Using this custom control in a XAML file that exists in a different project.
	/// Add this XmlNamespace attribute to the root element of the markup file where it is 
	/// to be used:
	///
	///     xmlns:MyNamespace="clr-namespace:Swordfish.WPF.Controls;assembly=Swordfish.WPF.Controls"
	///
	/// You will also need to add a project reference from the project where the XAML file lives
	/// to this project and Rebuild to avoid compilation errors:
	///
	///     Right click on the target project in the Solution Explorer and
	///     "Add Reference"->"Projects"->[Browse to and select this project]
	///
	///
	/// Step 2)
	/// Go ahead and use your control in the XAML file. Intellisense in the
	/// XML editor does not currently work on custom controls and its child elements.
	///
	///     <MyNamespace:UniformWrapPanel/>
	///
	/// </summary>
	public class UniformWrapPanel : Panel
	{
		// ********************************************************************
		// Private Fields
		// ********************************************************************
		#region Private Fields

		/// <summary>
		/// The size of the cells to draw in the panel
		/// </summary>
		private Size uniformSize;
		/// <summary>
		/// number of columns
		/// </summary>
        private int columnCount;
		/// <summary>
		/// number of rows
		/// </summary>
        private int rowCount;
		/// <summary>
		/// item ordering direction
		/// </summary>
        private Orientation itemOrdering = Orientation.Vertical;
		/// <summary>
		/// item position flow direction
		/// </summary>
        private Orientation wrapMode = Orientation.Horizontal;

		#endregion

		// ********************************************************************
		// Base Class Overrides
		// ********************************************************************
		#region Base Class Overrides


		/// <summary>
		/// Override the default Measure method of Panel 
		/// </summary>
		/// <param name="availableSize"></param>
		/// <returns></returns>
		protected override Size MeasureOverride(Size availableSize)
		{
			Size childSize = availableSize;
			uniformSize = new Size(1, 1);

			// Get the maximum size
			foreach (UIElement child in InternalChildren)
			{
				child.Measure(childSize);
				uniformSize.Width = Math.Max(uniformSize.Width, child.DesiredSize.Width);
				uniformSize.Height = Math.Max(uniformSize.Height, child.DesiredSize.Height);
			}

			// Work out the size required depending if we are going to flow them down the left side, or across the top
			switch (wrapMode)
			{
				case Orientation.Horizontal:
					columnCount = (int)Math.Max(1, Math.Min(InternalChildren.Count, availableSize.Width / uniformSize.Width));
					rowCount = (int)Math.Ceiling(InternalChildren.Count / (double)columnCount);
					if (itemOrdering == Orientation.Vertical && rowCount!=0)
						columnCount = (int)Math.Ceiling(InternalChildren.Count / (double)rowCount);
					break;
				case Orientation.Vertical:
					rowCount = (int)Math.Max(1, Math.Min(InternalChildren.Count, availableSize.Height / uniformSize.Height));
					columnCount = (int)Math.Ceiling(InternalChildren.Count / (double)rowCount);
					if (itemOrdering == Orientation.Horizontal && columnCount!=0)
						rowCount = (int)Math.Ceiling(InternalChildren.Count / (double)columnCount);
					break;
			}

			Size requestedSize = new Size(columnCount * uniformSize.Width, rowCount * uniformSize.Height);

			return requestedSize;
		}

		/// <summary>
		/// Override the default Arrange method
		/// </summary>
		/// <param name="finalSize"></param>
		/// <returns></returns>
		protected override Size ArrangeOverride(Size finalSize)
		{
			int columnNo = 0;
			int rowNo = 0;

			Size returnSize = new Size(
				Math.Max(uniformSize.Width, columnCount != 0 ? finalSize.Width / columnCount : 0),
				Math.Max(uniformSize.Height, rowCount != 0 ? finalSize.Height / rowCount : 0));

			Size renderedSize = new Size(Math.Round(uniformSize.Width), Math.Round(uniformSize.Height));

			foreach (UIElement child in InternalChildren)
			{
				child.Arrange(new Rect(new Point(Math.Round(columnNo * uniformSize.Width), Math.Round(rowNo * uniformSize.Height)), renderedSize));

				switch (itemOrdering)
				{
					case Orientation.Vertical:
						rowNo++;
						if (rowNo >= rowCount)
						{
							rowNo = 0;
							columnNo++;
						}
						break;
					case Orientation.Horizontal:
						columnNo++;
						if (columnNo >= columnCount)
						{
							columnNo = 0;
							rowNo++;
						}
						break;
				}
			}

			return new Size(returnSize.Width * columnCount, returnSize.Height * rowCount); // Returns the final Arranged size
		}

		#endregion Base Class Overrides

		// ********************************************************************
		// Properties
		// ********************************************************************
		#region Properties

		/// <summary>
		/// Gets sets the orientation of the order that items appear
		/// </summary>
		public Orientation ItemOrdering
		{
			get
			{
				return itemOrdering;
			}
			set
			{
				itemOrdering = value;
				InvalidateMeasure();
			}
		}

		/// <summary>
		/// Gets/Sets the method of flowing the layout of the items
		/// </summary>
		public Orientation WrapMode
		{
			get
			{
				return wrapMode;
			}
			set
			{
				wrapMode = value;
				InvalidateMeasure();
			}
		}

		#endregion Properties
	}
}



