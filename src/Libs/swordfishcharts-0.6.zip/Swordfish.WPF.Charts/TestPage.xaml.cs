/*
Copyright (c) 2007, John Stewien (formerly of Swordfish Computing Australia)

All rights reserved. Modified BSD License (removed some restrictions):

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.

Redistributions in binary form must retain the string:
"Swordfish Charts, Copyright (c) 2007, John Stewien"
in the XYLineChart.xaml.cs file.

Neither the name of Swordfish Charts nor the names of its contributors may be
used to endorse or promote products derived from this software without specific
prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

using System.Diagnostics;
using System.Windows;
using Microsoft.Win32;

namespace Swordfish.WPF.Charts
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class TestPage
    {
        public TestPage()
        {
            InitializeComponent();
			ChartUtilities.AddTestLines(xyLineChart);
			xyLineChart.SubNotes = new string[] { "Right Mouse Button To Zoom, Left Mouse Button To Pan, Double-Click To Reset" };
			copyToClipboard.CopyToClipboardDelegate = this.CopyChartToClipboard;
			copyToClipboard.SaveToFileDelegate = this.SaveToFile;
            //xyLineChart.FlipYAxis = true;
            //xyLineChart.PlotAreaOverride = new Rect(new Point(0, -2), new Point(5, 2));
		}

		public XYLineChart XYLineChart
		{
			get
			{
				return xyLineChart;
			}
		}

		/// <summary>
		/// Copies the chart to the clipboard
		/// </summary>
		/// <param name="element"></param>
		/// <param name="width"></param>
		/// <param name="height"></param>
		protected void CopyChartToClipboard(FrameworkElement element, double width, double height)
		{
            try
            {
                ChartUtilities.CopyChartToClipboard(plotToCopy, xyLineChart, width, height);
            }
            catch
            {
            	// the above might throw a security exception is used in an xbap
				Trace.WriteLine("Error copying to clipboard");
            }
		}

		protected void SaveToFile(FrameworkElement element, double width, double height)
		{
			SaveFileDialog saveFile = new SaveFileDialog();
			saveFile.Filter = "png files (*.png)|*.png";
			saveFile.AddExtension = true;
			saveFile.OverwritePrompt = true;
			saveFile.Title = "Save Chart To a File";
			saveFile.ValidateNames = true;

			if (saveFile.ShowDialog() == true)
			{
				ChartUtilities.CopyFrameworkElemenToPNGFile(plotToCopy, width, height, saveFile.FileName);
			}
		}
    }
}